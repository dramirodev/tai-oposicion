# 01 · Inventario documental

Se enumeraron 849 rutas de fichero y se leyó el contenido de cada una para calcular SHA-256. Hay 609 hashes distintos incluyendo metadatos internos. Los 410 PDF se extrajeron con Poppler página por página. En 20 rutas se halló al menos una página con menos de 40 caracteres tras retirar espacios extremos. La columna correspondiente indica qué páginas requieren inspección antes de utilizarse como prueba. La categoría X conserva 119 entradas de Git o Finder fuera del recuento de materiales educativos.

|Clase|Rutas|Contenido y tratamiento|
|---|---:|---|
|A|46|Teoría del temario facilitado. La ruta de Google Docs identifica un puntero nativo; su hash es local.|
|B|91|Cuadernos oficiales, incluidos turnos y modelos. Distinguir TAI, GSI y Junta de Andalucía.|
|C|114|Plantillas de respuestas. La cabecera permite comprobar si una plantilla es provisional o definitiva.|
|D|18|Simulacros de terceros. La procedencia impide contarlos en las frecuencias oficiales.|
|E|135|Tests, ejercicios y ficheros editoriales de preguntas o supuestos.|
|F|326|Material complementario, incluidos resúmenes, audio, archivos técnicos, convocatorias y anotaciones.|
|X|119|Metadatos técnicos.|

La carpeta 01_Temario organiza los materiales por tema. BANCO_PREGUNTAS conserva fuentes de autoría, revisiones, anotaciones y transformaciones. RECURSOS contiene las colecciones oficiales, las copias EXAMENES_OPO, material de convocatoria y simulacros. La lista de directorios incluye los vacíos. Las rutas se pueden filtrar por categoría, tema, convocatoria, cuerpo y versión. La columna copias_binarias cuenta todas las rutas con los mismos bytes. La reordenación de preguntas A/B y una remaquetación pueden conservar el contenido con otro hash. El cotejo de modelos se realiza en el informe oficial.

[Manifiesto con rutas originales, páginas y hashes](anexos/manifest.csv) · [Directorios](anexos/directorios.txt)

Se abrieron los dos documentos nativos a partir de su identificador Drive. El catálogo GSI registra modificación el 28 de octubre de 2026. El documento de Constitución denominado «corregido» registra modificación el 31 de julio de 2026 y su texto conserva tres reformas. La edición alternativa del PDF T1.01, en su página 4, recoge cuatro; el historial normativo permite resolver la discrepancia. [Constitución, historial de redacciones](https://www.boe.es/buscar/act.php?id=BOE-A-1978-31229).

El PDF rotulado «Examen TAI 2018 - Cuestionario 2o ejercicio» coincide byte por byte con 07TAIL_154AB89SD658.pdf del primer ejercicio (SHA-256 459eafc82ea1297e989d5933679ab17c5814adbd432291d33bd7421738ba3c9c). Para citar el ejercicio se conserva la ruta administrativa de referencia además del nombre de la copia. [Grupos de duplicados](anexos/duplicados-documentales.csv).

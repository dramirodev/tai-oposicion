# 10 · Registro de hallazgos

El identificador ITEM seguido del ID de pregunta permanece estable entre lotes. Cada fila contiene la pregunta, el motivo de discrepancia, su prioridad y la evidencia para adjudicarla. [Registro por ID](anexos/incidencias-por-id.csv). Se incluyen también los dictámenes parciales, con la revisión íntegra en el [registro completo](banco/dictamenes.json).

|ID técnico|Prioridad|Descripción, evidencia y criterio de cierre|
|---|---|---|
| TEC-01 | P0 si se recompila para publicar | Compilar en una carpeta vacía los JSON de Drive conserva todos los IDs pero modifica 9.693 registros: 149 con opciones distintas, 131 enunciados, 2 claves y 7 marcas de exclusión puntuable. AS12B-S1-02 cambiaría A→B y AS12B-S2-12 C→B. El segundo cambia también redacción y opciones. Son diferencias del artefacto reconstruido; no se escribió en producción. Exigir que un manifiesto de correcciones explique cada cambio de clave, preserve `np` y detenga la publicación ante discrepancias. [Detalle por ID](evidencia-tecnica/cambios-de-reconstruccion.csv). |
| TEC-02 | P1 | La configuración presentada como simulacro completo permite tiempos, parejas y notas diferentes de las bases. Exigir una prueba de una sesión íntegra con reloj compartido, dos casos de bloques distintos, selección única, reservas y dos mínimos por convocatoria. |
| TEC-03 | P0 en práctica | En la práctica guiada se respondió incorrectamente a `GEN-T3.03-48` marcada `np=1`. El resultado fue un fallo, nota −33,3 y un intento en las estadísticas locales. En el simulacro sí se filtra. Separar exposición de evaluación en las siete filas marcadas y probar todos los puntos de entrada. |
| TEC-04 | P1 | El detector marca nueve académicas que aluden a una figura, entre ellas `AS01-P1-88` sobre un recuadro azul. Las nueve carecen de `np`. Algunas incluyen descripción sustitutiva, como `AS01-P1-100`. La revisión individual descubrió otras omisiones esenciales fuera de esa lista, como el código de `AS09-P1-52` o el grafo de `AS08B-P1-37`. El detector también marca seis generadas resolubles sin imagen. Adjuntar imagen, descripción equivalente verificable o excluir de evaluación donde sea imprescindible. [Lista y enunciados](evidencia-tecnica/analisis.json). |
| TEC-05 | P1 ante cambio de edición | Se probó `loadPendingRun` con respuesta guardada y catálogo del mismo ID con clave distinta. Acepta la reanudación. La huella de resaltados `questionContentRevision` usa enunciado y opciones. Guardar la revisión de contenido y rúbrica al inicio y resolver incompatibilidades antes de puntuar; se detectó el riesgo, no se observaron historiales afectados. |
| TEC-06 | P1 | En el constructor externo T2.05 la cita se busca en el texto normalizado completo, se asigna «verificada» al resultado, y los errores acumulados se imprimen después de guardar el JSON. Exigir comprobación de página, fallo explícito y separación entre borrador y aprobado. |
| TEC-07 | P2 | Las cuatro configuraciones medidas excluyen temas con contenido disponible; O+G entrega más de 92 % de generadas. Fijar objetivo de cada modo y contrastar cumplimiento por tema, familia y patrón en varias sesiones. Reutilizar la exclusión actual de variantes en la misma forma. |
| TEC-08 | P2 | La proyección abreviada de citas y la publicación docente vacía impiden saber desde la app qué epígrafe respalda cada distractor. Añadir manifiesto editorial asociado al ID estable y versión de contenido, manteniendo legible el contrato histórico. Reservar dificultad empírica y discriminación para datos reales, con exposición previa y calidad de muestra controladas. |

Todos los hallazgos técnicos están ANALIZADOS. TEC-03 implica un error de puntuación reproducido en práctica y debe tratarse como P0 para esa modalidad. Consultar las caracterizaciones ejecutadas antes de aplicar una corrección. [Informe técnico](07-tests-simulacros-y-almacenamiento.md) · [Resultados](evidencia-tecnica/pruebas.txt).

|ID transversal|Prioridad y estado|Evidencia y cierre|
|---|---|---|
|DOC-01|P2 · ANALIZADO|El nombre de la copia del ejercicio de 2018 contradice su identidad binaria. Resolver la procedencia por hash y expediente al citarla. Véase informe 01.|
|PED-01|P2 · ANALIZADO|Escoger por longitud permite un 51,03 % esperado en generadas. Comparar el indicador de lote tras revisar opciones, con desglose por tema y demanda cognitiva.|
|TRA-01|P1 · ANALIZADO|L2018-P1-06 tiene alias P2018-P1-06 sobre Agenda 2030; el contenido aparece en la 7 de la página 2 del cuaderno de promoción interna. Corregir la relación por modelo tras resolver enunciado, opciones y número.|

<!-- RESULTADOS DEL CENSO -->
## Alcance del registro

Hay 3.519 filas ITEM, una por pregunta con alguna reserva de calidad. El CSV permite filtrar por estado del análisis, prioridad y clasificación semántica. Los dictámenes parciales incluyen limitaciones en explicación, condiciones o fuente y no implican de por sí una clave errónea. Los identificadores TEC, DOC, PED y TRA agrupan problemas transversales y se presentan por separado.

| Origen | Revisadas | Validadas | Parciales | Ambiguas | Incorrectas | Posible obsolescencia | Sin respaldo |
|---|---:|---:|---:|---:|---:|---:|---:|
| Oficial | 1.049 | 771 | 197 | 39 | 14 | 13 | 15 |
| Academia | 4.106 | 2.786 | 770 | 348 | 144 | 29 | 29 |
| Generada | 10.923 | 9.002 | 1.266 | 244 | 279 | 123 | 9 |
| **Total** | 16.078 | 12.559 | 2.233 | 631 | 437 | 165 | 53 |

[Registro editorial por ID](anexos/incidencias-por-id.csv) · [Censo íntegro con pregunta, opciones, clave y juicio](banco/inventario.jsonl).

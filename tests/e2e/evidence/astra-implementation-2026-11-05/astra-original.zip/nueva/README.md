# Auditoría integral TAI · Nuevo corte del 5 de noviembre

Se ha rehecho la auditoría desde los originales. El censo contiene **16.078 preguntas**. Hay **16.078 dictámenes semánticos individuales y 0 IDs pendientes**. Los resultados por estado son 12.559 validadas, 2.233 parcialmente respaldadas, 165 potencialmente obsoletas, 631 ambiguas, 437 incorrectas, 53 sin respaldo.

|Origen|Banco|Dictamen individual|Pendiente|
|---|---:|---:|---:|
|Oficial|1.049|1.049|0|
|Academia|4.106|4.106|0|
|Generada|10.923|10.923|0|

Los dictámenes corresponden a la revisión del asistente, sin segunda firma editorial. Las cifras de cobertura documental son diferentes: 8.891 IDs tienen una cita recuperada en teoría principal; al admitir los resúmenes identificados de T3.06 ascienden a 10.090 (62,76 %). Una coincidencia puede apuntar a una afirmación caducada o a la parte equivocada del razonamiento. [Dictámenes individuales](banco/dictamenes.json) · [Control de pendientes (0 filas de datos)](banco/pendientes-semanticos.csv).

En las 4.106 preguntas de academia se cotejó la letra publicada con la tabla de soluciones impresa, identificando parte, reserva y número. Se observaron 4.103 coincidencias y tres diferencias con nota editorial en la app. En 215 preguntas de completar huecos, sustituir las opciones dentro de su contexto próximo recuperó únicamente la clave en 97, varias opciones en dos y ninguna frase literal en 116. Estas comprobaciones tienen sus propios denominadores y no elevan la cifra de dictámenes individuales. [Claves académicas](anexos/claves-academia.csv) · [Sustitución de alternativas](anexos/huecos-contexto.csv).

Un piloto del modelo local de Apple contrastó ocho preguntas sin ver la clave publicada. En varias devolvió todas las letras; en AS03-P1-72 rechazó el postorden que se obtiene al reconstruir el árbol. Las ocho respuestas se descartaron. La prioridad operativa es proteger las claves, las anulaciones y las exclusiones al puntuar, y hacer reproducible la reconstrucción del banco antes de generar contenido adicional.

## Informes

- [01 · Inventario documental](01-inventario.md)
- [02 · Qué preguntas contiene la aplicación](02-banco.md)
- [03 · Qué respaldo y qué calidad se han podido demostrar](03-calidad.md)
- [04 · Cómo preguntan los exámenes oficiales TAI y GSI](04-ingenieria-inversa.md)
- [05 · Catálogo de patrones observados](05-catalogo-patrones.md)
- [06 · Qué distingue el banco del examen y dónde revisar cobertura](06-comparacion.md)
- [07 · Tests, simulacros y almacenamiento](07-tests-simulacros-y-almacenamiento.md)
- [08 · Especificación del futuro generador](08-generacion-y-validacion.md)
- [09 · Plan de mejoras priorizado](09-plan-de-mejoras.md)
- [10 · Registro de hallazgos](10-hallazgos.md)

<!-- RESULTADOS DEL CENSO -->
## Resultados de la revisión

| Origen | Revisadas | Validadas | Parciales | Ambiguas | Incorrectas | Posible obsolescencia | Sin respaldo |
|---|---:|---:|---:|---:|---:|---:|---:|
| Oficial | 1.049 | 771 | 197 | 39 | 14 | 13 | 15 |
| Academia | 4.106 | 2.786 | 770 | 348 | 144 | 29 | 29 |
| Generada | 10.923 | 9.002 | 1.266 | 244 | 279 | 123 | 9 |
| **Total** | 16.078 | 12.559 | 2.233 | 631 | 437 | 165 | 53 |

**Respaldo y prioridades.** El 55,30 % del banco cuenta con una cita de autoría recuperada en el temario principal. Al admitir los resúmenes identificados, la cobertura literal sube al 62,76 %. Entre los problemas que afectan a la nota destacan las claves incorrectas, más de una solución defendible y una pregunta marcada como no puntuable que genera un fallo en práctica. En reconstrucción se observaron cambios en dos claves y siete marcas de exclusión. [Prioridades y pruebas de aceptación](09-plan-de-mejoras.md).

**Qué practicar.** En las cuatro convocatorias examinadas se repiten los cambios de alcance y los distractores de conceptos próximos. La técnica de código o cálculo figura en el 20,11 % de los IDs oficiales y en el 0,77 % de las generadas. Los epígrafes sin asignación por cita incluyen los 42 de T4.01 y 23 de los 28 de T3.09. [Comparación y brechas](06-comparacion.md).

Para reproducir la conciliación, ejecutar `python3 metodo/verificar_cierre.py` desde el directorio descomprimido `nueva`. El programa comprueba las huellas de contenido, las clasificaciones, las incidencias y los enlaces locales. [Comprobador del paquete](metodo/verificar_cierre.py).

**Respaldo por pregunta.** Las 10.090 coincidencias literales proceden de citas de autoría de las generadas. Para incorporar también la evidencia localizada durante esta revisión se buscaron los nombres de los 51 PDF de teoría y una página en rango dentro de cada dictamen. 15.523 registros citan así al menos una página. De ellos, **12.288 (76,43 % de todo el banco)** combinan esa referencia con un dictamen «Validada». Son 770 oficiales, 2.522 de academia y 8.996 generadas. El indicador permite filtrar los juicios favorables con una referencia interna comprobable. Excluye referencias abreviadas que el programa no pudo identificar, así como pruebas basadas exclusivamente en cálculos, cuadernos o fuentes externas. Una página citada puede acreditar solo parte del razonamiento. [Desglose de los indicadores por ID](banco/respaldo-por-id.csv) · [Método de recuento](metodo/medir_respaldo.py).

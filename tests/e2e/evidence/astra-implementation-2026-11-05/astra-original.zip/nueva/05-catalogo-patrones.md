# 05 · Catálogo de patrones observados

Se clasificó el principal mecanismo que separa las alternativas en 39 preguntas revisadas de cuatro convocatorias y cinco llamamientos. El tribunal publicó textos y claves; las categorías, demandas y riesgos corresponden a esta auditoría. Los ejemplos remiten al PDF y página del anexo 04. Las proporciones describen únicamente esta muestra sistemática.

| Código | Patrón | N/39 | Convocatorias | Evidencia |
|---|---|---|---|---|
| CIF | Combinación de cantidades y condiciones | 4/39 | 2019, 2024, 2025 | consolidado en la muestra |
| CLA | Cambio de alcance o de propiedad | 13/39 | 2019, 2022, 2024, 2025 | consolidado en la muestra |
| FAM | Conceptos de una misma familia | 11/39 | 2019, 2022, 2024, 2025 | consolidado en la muestra |
| INS | Elección de instrucción o fragmento | 7/39 | 2019, 2024, 2025 | consolidado en la muestra |
| CAL | Resultado de un cálculo con datos del supuesto | 3/39 | 2019, 2025 | recurrente, evidencia limitada |
| ACT | Elección de actuación operativa | 1/39 | 2024 | ocasional |

### CIF · Combinación de cantidades y condiciones

Una opción conserva el dato y otro atributo, como órgano, unidad, máscara o transporte. Recuerdo o discriminación de dos propiedades. En la muestra aparece en **4/39** ítems utilizables. Se clasifica como consolidado en la muestra.

**Ejemplos.** TAI-2019-L-U-P1-03 (p. 2, Composición del Tribunal Constitucional); TAI-2024-L-A-P1-50 (p. 5, Plazo de respuesta y cómputo de días); TAI-2025-L-X-P1-72 (p. 7, Puerto y transporte SIP).

**Validación.** Variar un solo componente o ambos. Exigir que una sola combinación satisfaga toda la fuente. Distinguir un plazo hábil de uno natural antes de validar las cifras.

### CLA · Cambio de alcance o de propiedad

Las opciones contienen proposiciones completas. Una cambia una propiedad definitoria, una condición, un sujeto o una consecuencia. Distinguir afirmaciones próximas o interpretar un resultado. En la muestra aparece en **13/39** ítems utilizables. Se clasifica como consolidado en la muestra.

**Ejemplos.** TAI-2019-L-U-P1-28 (p. 4, SSD, expansión del acrónimo y tecnología); TAI-2022-L-U-P1-28 (p. 3, Conector USB y versión del protocolo); TAI-2024-L-A-P1-03 (p. 1, Competencias del Rey y condición de autorización); TAI-2025-L-A-P1-03 (p. 1, Diputación Permanente).

**Validación.** Enunciar por separado la cláusula de cada alternativa que la hace verdadera o falsa bajo las condiciones dadas. Una formulación generalmente cierta también puede ser defendible. Revisar excepciones.

### FAM · Conceptos de una misma familia

El enunciado aporta una propiedad, objetivo o definición. Las opciones proponen términos próximos que se aplican a problemas distintos. Reconocimiento y discriminación. En la muestra aparece en **11/39** ítems utilizables. Se clasifica como consolidado en la muestra.

**Ejemplos.** TAI-2019-L-U-P1-50 (p. 6, Finalidad de Ruby on Rails); TAI-2022-L-U-P1-03 (p. 1, Circunscripción electoral); TAI-2024-L-A-S1-12 (p. 9, Descripciones de servicios web); TAI-2025-L-A-P1-28 (p. 3, Finalidad de IPP).

**Validación.** Vincular cada alternativa a una definición o uso real y demostrar por qué no se aplica aquí. Los términos podrían solaparse por jerarquía o versión.

### INS · Elección de instrucción o fragmento

Un requisito acota el resultado esperado. Las alternativas cambian sintaxis, parámetro, operador, orden o verbo. Aplicación de una regla, interpretación de código. En la muestra aparece en **7/39** ítems utilizables. Se clasifica como consolidado en la muestra.

**Ejemplos.** TAI-2019-L-U-S1-03 (p. 10, Atributo HTML obligatorio); TAI-2024-L-A-S1-03 (p. 8, INSERT INTO y literales); TAI-2025-L-A-S1-03 (p. 9, Agregación SQL por programa).

**Validación.** Contrastar el efecto bajo entorno, versión y entradas fijados. Cuando proceda, ejecutar las cuatro alternativas. Una variante distinta puede producir el mismo efecto.

### CAL · Resultado de un cálculo con datos del supuesto

Unos datos de entrada y una restricción producen una solución numérica. Las otras opciones también son resultados expresados en las unidades esperadas. Aplicación y cálculo. En la muestra aparece en **3/39** ítems utilizables. Se clasifica como recurrente, evidencia limitada.

**Ejemplos.** TAI-2019-L-U-S2-03 (p. 13, Hosts de una subred /21); TAI-2025-L-A-S2-03 (p. 12, División de /21 en cuatro subredes).

**Validación.** Recalcular la solución y documentar qué operación concreta produciría cada distractor propuesto. Confundir el tamaño de la red con el número de hosts utilizables.

### ACT · Elección de actuación operativa

Una situación de implantación o diagnóstico admite varias actuaciones descritas. Se elige la compatible con el objetivo expresado. Razonamiento sobre escenario. En la muestra aparece en **1/39** ítems utilizables. Se clasifica como ocasional.

**Ejemplos.** TAI-2024-L-A-S2-03 (p. 11, Puerto 80 y redirección HTTPS).

**Validación.** Verificar permisos, objetivo, estado inicial y efecto de las alternativas. Si el objetivo permite dos soluciones, remitir a revisión.

## Criterio de uso

«Consolidado en la muestra» exige presencia en tres o más convocatorias. Dos o más ejemplos en una o dos convocatorias constituyen evidencia recurrente limitada. Un único caso se registra como ocasional. Un patrón no fija cuotas del generador. Para reutilizarlo, se comienza por el contenido verificable, se identifica la confusión exacta y se valida cada opción bajo las mismas condiciones. Una pregunta inversa constituye una forma de enunciado y puede combinarse con cualquiera de los mecanismos anteriores.

[Catálogo estructurado y temas de aplicación](oficial/catalogo.csv) · [40 posiciones revisadas, incluida la anulada](oficial/muestra-revisada.csv).

<!-- RESULTADOS DEL CENSO -->
## Uso editorial de los patrones recurrentes

En las cuatro convocatorias del perfil aparecen alternativas que cambian el alcance de una propiedad (13/39) y alternativas de conceptos de la misma familia (11/39). Para diseñar una pregunta, conservar el hecho que el estudiante deba distinguir, redactar tres errores interpretativos plausibles y comprobar que cada uno falla con las premisas exactas del enunciado. El ejemplo oficial identifica el mecanismo y la página del temario acredita el nuevo contenido. [Matriz de los ejemplos oficiales y los candidatos del banco](banco/matriz-patrones-revisados.csv).

### Etiquetas de autoría contrastadas con las posiciones de examen

Se enlazaron 661 de las 663 posiciones del perfil TAI con un único ID del banco aplicando conjuntamente similitud de enunciado de al menos 0,96, concordancia de las cuatro opciones en el mismo orden y coincidencia de la respuesta correcta. La tabla usa la técnica asignada por los autores del banco. La muestra independiente de 39 preguntas utiliza el catálogo de esta auditoría y se contabiliza por separado. Los cinco llamamientos contienen ejemplos de las seis técnicas editoriales.

| Cuaderno | Posiciones | Vínculos | Conceptos próximos | Deformación literal | Código o cálculo | Cifra o plazo | Intruso | Opciones inventadas |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| TAI-2019-L-U | 135 | 135 | 31 | 25 | 37 | 18 | 13 | 11 |
| TAI-2022-L-U | 129 | 129 | 33 | 33 | 12 | 14 | 23 | 14 |
| TAI-2024-L-A | 131 | 130 | 42 | 40 | 18 | 12 | 12 | 6 |
| TAI-2025-L-A | 133 | 133 | 30 | 32 | 38 | 15 | 14 | 4 |
| TAI-2025-L-X | 135 | 134 | 37 | 29 | 31 | 15 | 14 | 8 |

[Las 663 posiciones, incluidas las dos sin vínculo estricto](oficial/patron-por-posicion-TAI.csv) · [Reproducir el cruce](metodo/cruzar_patrones_oficiales.py).

# Handoff · Auditoría TAI

**16.078 de 16.078 IDs tienen un dictamen semántico. Quedan 0 pendientes de esa revisión.**

| Origen | Revisadas | Validadas | Parciales | Ambiguas | Incorrectas | Posible obsolescencia | Sin respaldo |
|---|---:|---:|---:|---:|---:|---:|---:|
| Oficial | 1.049 | 771 | 197 | 39 | 14 | 13 | 15 |
| Academia | 4.106 | 2.786 | 770 | 348 | 144 | 29 | 29 |
| Generada | 10.923 | 9.002 | 1.266 | 244 | 279 | 123 | 9 |
| **Total** | 16.078 | 12.559 | 2.233 | 631 | 437 | 165 | 53 |

**Dónde retomar.** El siguiente trabajo es editorial. Empezar por las claves incorrectas, las anulaciones oficiales y la exclusión de nota. Cotejar la pregunta, las alternativas y su edición, registrar quién adjudica la incidencia y probar en práctica y en simulacro antes de publicar un cambio. El registro contiene 3.519 IDs con alguna reserva de calidad y permite filtrar los P0. [Registro editorial por ID](anexos/incidencias-por-id.csv) · [Plan priorizado](09-plan-de-mejoras.md).

**Qué sigue abierto fuera del censo.** Segunda revisión editorial independiente de los dictámenes, lectura visual exhaustiva de los textos OCR antes de republicarlos, decisión sobre nuevas transferencias GSI y correcciones de producto. Para medir dificultad, discriminación o retención hacen falta datos de primeros intentos válidos. Los extractos y las páginas candidatas deben contrastarse con la edición antes de aprobar un cambio.

**Comprobación.** El inventario conserva enunciado, opciones en su orden publicado, clave, familia, origen, fuente y juicio. La huella cubre también supuesto, extracto y nota. Si cambia el banco, comparar esas huellas y revisar los IDs afectados. Un cambio en el material gráfico o la normativa de referencia exige reabrir el dictamen aunque la huella textual coincida. [Índice y diez informes](README.md) · [Dictámenes](banco/dictamenes.json) · [IDs sin dictamen](banco/pendientes-semanticos.csv) · [Cobertura por tema y procedencia](banco/cobertura-por-tema.csv) · [Comprobador del paquete](metodo/verificar_cierre.py).

<!-- RESUMEN -->
Banco v12 verificado por lectura de 39 documentos y cotejo de bytes. Diez informes. Revisión semántica completa con 16.078 dictámenes individuales de 16.078 y 0 IDs pendientes.

"""Cruza los perfiles oficiales con etiquetas de autoría, conservando el criterio de enlace."""
from collections import Counter, defaultdict
from pathlib import Path
import csv
import json

root = Path(__file__).resolve().parents[1]
def rows(name):
    with (root / name).open(newline='') as f:
        return list(csv.DictReader(f))

questions = {q['id']: q for q in map(json.loads,(root / 'banco/inventario.jsonl').open())}
joins = defaultdict(list)
for r in rows('banco/contraste-plantillas.csv'):
    if (float(r['similitud_enunciado'] or 0) >= .96
        and r['cuatro_opciones_mismo_orden'] == 'True'
        and r['dictamen'] == 'coincide el texto de la alternativa correcta'):
        joins[r['oficial']].append(r['banco'])
labels = {'M':'cifra o plazo','K':'código o cálculo','F':'deformación literal','H':'conceptos hermanos','X':'intruso entre familias','V':'opciones inventadas'}
source = [q for q in rows('oficial/preguntas.csv') if q['perfil']=='1' and q['cuaderno'].startswith('TAI')]
counts = defaultdict(Counter)
fields = ['posicion_oficial','cuaderno','pagina','tema_en_banco','id_banco','tecnica_autoria','patron_muestra','demanda_muestra','metodo']
with (root / 'oficial/patron-por-posicion-TAI.csv').open('w',newline='') as f:
    writer=csv.DictWriter(f,fieldnames=fields)
    writer.writeheader()
    for row in source:
        ids=set(joins[row['id']])
        key=next(iter(ids)) if len(ids)==1 else ''
        item=questions.get(key,{})
        label=labels.get(item.get('tecnica_autoria'),'')
        counts[row['cuaderno']][label]+=1
        writer.writerow(dict(posicion_oficial=row['id'],cuaderno=row['cuaderno'],pagina=row['pagina'],tema_en_banco=item.get('tema',''),id_banco=key,tecnica_autoria=label,patron_muestra=row['patron_revisado'],demanda_muestra=row['demanda_revisada'],metodo='Vínculo único, similitud ≥0,96, opciones en el mismo orden y respuesta concordante.' if key else 'Sin enlace que satisfaga todos los umbrales.'))
assert sum(c.total() for c in counts.values()) == 663
if __name__ == '__main__':
    for code,c in sorted(counts.items()): print(code,dict(c))

"""Buscar contradicciones sin perder mayúsculas, negaciones ni operadores."""
import json,csv,collections,itertools,difflib,unicodedata
from pathlib import Path
p=Path('outputs/nueva')
def norm(s):return ' '.join(unicodedata.normalize('NFC',s).split()).rstrip('.')
g=collections.defaultdict(list)
for q in map(json.loads,(p/'banco/inventario.jsonl').open()):
 g[tuple(sorted(map(norm,q['opciones'])))].append(q)
rows=[]
for opts,items in g.items():
 for x,y in itertools.combinations(items,2):
  if norm(x['respuesta'])==norm(y['respuesta']):continue
  a,b=norm(x['pregunta']),norm(y['pregunta'])
  score=difflib.SequenceMatcher(None,a,b,autojunk=False).ratio()
  if score>=.82:rows.append((round(score,4),x['id'],y['id'],a,b,x['respuesta'],y['respuesta']))
with (p/'anexos/claves-distintas-opciones-iguales.csv').open('w') as f:
 w=csv.writer(f);w.writerow(['similitud','id1','id2','enunciado1','enunciado2','clave_textual1','clave_textual2']);w.writerows(sorted(rows,reverse=True))
print(len(rows));print(sorted(rows,reverse=True)[:3])

from pathlib import Path
# Reanclaje por posición y número impreso. Cada tramo es (número de ítem, primera línea OCR de la página).
SECTIONS=[
('GSI-2018-L-U','P1','1a1dfd81ee43',4,[(19,1),(20,7),(21,13),(22,16),(31,63),(None,68)]),
('GSI-2018-L-U','P1','1a1dfd81ee43',6,[(45,1),(46,6),(47,14),(48,19),(49,24),(50,29),(51,38),(52,42),(53,48),(54,53),(55,58),(56,61),(57,66)]),
('GSI-2018-P-U','P1','438726a0cbbe',3,[(15,59),(16,68),(None,71)]),
('GSI-2018-P-U','P1','438726a0cbbe',6,[(60,46),(61,50),(None,54)]),
('GSI-2018-P-U','P1','438726a0cbbe',7,[(68,14),(69,21),(None,32)]),
('TAI-2018-L-II','S1','1ae6e873e026',4,[(11,1),(None,16)]),
('TAI-2018-L-II','S2','1ae6e873e026',8,[(14,21),(None,27)]),
('TAI-2018-L-U','P1','459eafc82ea1',6,[(52,16),(None,21)]),
('TAI-2018-P-U','P1R','99abc22c9c8f',5,[(1,55),(2,66),(3,72),(4,76),(5,80)]),
('TAI-2018-P-U','S1','99abc22c9c8f',6,[(1,31),(2,37),(3,43)])]
import re
def ordinales(r,lines):
 if all(r.get(c) for c in 'abcd'):return
 options=[]
 for raw in lines:
  l=re.sub(r'^[|!¡iItj1\[\]()]{1,2}\s+', '',raw.strip())
  for seg in re.split(r'\s{2,}(?=[a-eA-E0-9çÇ]{1,2}\s*[)\]]\s*)',l):
   m=re.match(r'^([a-eA-E0-9çÇ]{1,2})\s*[)\]]\s*(.*)',seg)
   if m:options.append([m[1].lower(),m[2]])
   elif options:options[-1][1]+=' '+seg
 if len(options)==4 and sum(g.endswith(k) for (g,v),k in zip(options,'abcd'))>=2 and all(v.strip() for g,v in options):
  for c,(g,v) in zip('abcd',options):r[c]=v.strip()

def amend(rows):
 index={r['id']:r for r in rows}
 for ex,section,directory,page,groups in SECTIONS:
  f=next(p for p in (Path('work/reinicio-oficial')/directory).glob('*.jpg.txt') if int(p.name.split('-')[1].split('.')[0])==page)
  lines=f.read_text().splitlines()
  for i,(n,start) in enumerate(groups):
   if not n:continue
   # Only recover the first two newly delineated items when the next segment is simply an anchor.
   if ex=='GSI-2018-L-U' and page==4 and n==22:continue
   end=groups[i+1][1]-1 if i+1<len(groups) else len(lines)
   r=index[f'{ex}-{section}-{n:02}'];raw=lines[start-1:end];out={};which='enunciado'
   for j,l in enumerate(raw):
    l=l.strip()
    if not l or 'Página ' in l or re.match(r'^2018',l):continue
    if j==0:l=re.sub(r'^.{1,8}?(?:\s{2,}|\.\s+|,\s+)', '',l).lstrip('— ');out['enunciado']=l;continue
    l=re.sub(r'^[|¡!jIt1\[\]]\s+', '',l)
    for seg in re.split(r'\s{2,}(?=[a-dAC][)\]])',l):
     marker=re.match(r'^(?:[aACc0e])?([abcdACD])\s*[)\]]\s*(.*)',seg)
     if marker:which=marker[1].lower();out[which]=marker[2]
     elif which!='d' or len(seg)>4:out[which]=out.get(which,'')+' '+seg
   ordinales(out,raw[1:])
   r.update(pagina=page,estado='OCR reanclado; revisar texto',enunciado=out.get('enunciado',''),**{c:out.get(c,'') for c in 'abcd'})

def validar_opciones_visuales(rows):
 opciones = """GSI-2018-L-U-P1-84|224.0.0.0/4|232.0.0.0/8|239.0.0.0/8|240.0.0.0/4
GSI-2018-P-U-P1-17|24|5|7|30
GSI-2018-P-U-P1-24|Swift|Objetive-C|R|Python
GSI-2018-P-U-P1-26|RIP|GRIP|BGP|IGRP
GSI-2018-P-U-P1-30|Agrupamiento.|Síntesis automática.|Remolino.|Pinball.
GSI-2018-P-U-P1-32|Diagrama de colaboración.|Diagrama de representación.|Diagrama de estructura.|Diagrama de componentes.
GSI-2018-P-U-P1-36|0|1|2|3
GSI-2018-P-U-P1-44|Fan in.|Fan out.|Cohesión secuencial.|Cohesión comunicacional.
GSI-2018-P-U-P1-71|*|//|//*|/*
GSI-2018-P-U-P1-77|254|14|28|256
GSI-2018-P-U-P1-78|53 y 54|161 y 162|25 y 26|179 y 180
GSI-2018-P-U-P1-84|BGP|RIP|OSPF|IS-IS
GSI-2018-P-U-P1-94|1,4 - 1,8 GHz.|2,4 GHz.|3,4 - 3,8 GHz.|5 GHz.
TAI-2018-L-II-S1-21|4|5|6|8
TAI-2018-L-II-S2-03|172.30.31.255|172.30.255.255|172.30.23.255|172.30.14.255
TAI-2018-L-II-S2-21|A|MX|CNAME|TXT
TAI-2018-L-II-S2R-02|172.30.8.0|172.30.14.1|172.30.16.1|172.30.23.1
TAI-2018-L-U-P1-30|1|2|3|4
TAI-2018-L-U-P1-92|190.11.255.255 y 190.10.30.40|19.24.48.35 y 19.132.250.35|246.2.8.44 y 246.2.240.3|213.45.128.8 y 213.45.126.74
TAI-2018-P-U-P1-22|D|O|U|Es_un
TAI-2018-P-U-P1-47|10.16.7.2|192.168.25.34|172.16.256.22|183.45.33.12
TAI-2018-P-U-S2-05|10.255.255.255|10.1.255.255|10.1.254.255|10.1.248.255
TAI-2018-P-U-S2-06|arp -all|arp -i|arp -a|arp -g"""
 idx={r['id']:r for r in rows}
 for line in opciones.splitlines():
  ident,*values=line.split('|');assert len(values)==4
  idx[ident].update(dict(zip('abcd',values)));idx[ident]['estado']='OCR con cuatro opciones cotejadas visualmente'
 idx['TAI-2018-L-II-S1-21']['enunciado']='Indique qué número hay que pasar como parámetro a la siguiente función Java para que produzca como salida el número 8: int secuencia(int n){ if(n==1 || n==2) return 1; else return secuencia(n-1)+secuencia(n-2); }'
 idx['TAI-2018-P-U-P1-06'].update(enunciado='Según se establece en la Ley 19/2013, de Transparencia, Acceso a la Información Pública y Buen Gobierno, en su artículo 11 se establecen los principios a los que tendrá que adecuarse la información publicada en el Portal de Transparencia. Estos principios son:',a='Accesibilidad, integridad e interoperabilidad.',b='Accesibilidad, reutilización e interoperabilidad.',c='Accesibilidad, disponibilidad y reutilización.',d='Accesibilidad, disponibilidad e integridad.',estado='Inspección visual enunciado y opciones')
 idx['TAI-2018-P-U-P1-07'].update(enunciado='¿En qué año se aprobó la Agenda 2030 para el desarrollo sostenible?',a='2015',b='2016',c='2017',d='2018',estado='Inspección visual enunciado y opciones')

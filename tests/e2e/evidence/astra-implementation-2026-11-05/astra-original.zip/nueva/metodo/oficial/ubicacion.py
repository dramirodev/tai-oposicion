"""Agrega apartados candidatos mediante folio impreso, preservando estado de evidencia."""
import csv,re,subprocess,collections
from pathlib import Path
D=Path('outputs/nueva/oficial');T=Path('/Volumes/SSD/Google Drive/TEMARIO_OPOSICION/01_Temario')
def load(f):
 with f.open() as h:return list(csv.DictReader(h))
def save(f,rows):
 with f.open('w') as h:
  w=csv.DictWriter(h,list(dict.fromkeys(k for r in rows for k in r)));w.writeheader();w.writerows(rows)
index=collections.defaultdict(list)
for r in load(D.parent/'banco/apartados.csv'):
 index[r['documento']].append((int(r['pagina_impresa']),r['apartado'],r['concepto']))
data=load(D/'preguntas.csv'); cache={};hist=collections.Counter(); cognitive=collections.Counter()
for r in data:
 sec=r['seccion'];tags=set(r['marcas'].split('|')); ex=r['cuaderno'];c=r.get('demanda_revisada','')
 tendencies=[]
 if 'seleccion inversa' in tags:tendencies.append('detectar excepción o proposición falsa')
 if 'definicion' in tags:tendencies.append('reconocer definición')
 if 'instruccion' in tags:tendencies.append('identificar o interpretar instrucción')
 if 'comparacion' in tags:tendencies.append('distinguir conceptos')
 if 'secuencia' in tags:tendencies.append('ordenar elementos')
 r['demanda_indicio']='|'.join(tendencies) if tendencies else 'sin señal léxica concluyente'
 r['nivel_evidencia_demanda']='revisión de las cuatro opciones' if c else 'indicador lingüístico; confirmar leyendo el ítem'
 r['contexto_general']='consultar portada del supuesto '+sec[:2]+' en el cuaderno' if sec.startswith('S') else ''
 if r['perfil']=='1':
  for t in tendencies or ['sin señal léxica concluyente']:cognitive[ex,t]+=1
 f=r.get('pdf_candidato');p=r.get('pag_candidata','')
 if not f or not p:continue
 name=str(Path(f).relative_to(T))
 if name not in index:continue
 if f not in cache:
  pages=subprocess.check_output(['pdftotext','-layout',f,'-']).decode().split('\f')
  cache[f]=[re.findall(r'\bp[áa]gina\s+(\d+)\b',page[-350:],re.I) for page in pages]
 footer=cache[f][int(p)-1]
 if not footer:continue
 printed=int(footer[-1]);eligible=[i for i in index[name] if i[0]<=printed]
 if not eligible:continue
 start,ident,heading=max(eligible,key=lambda v:v[0])
 r.update(apartado_candidato=ident,titulo_apartado_candidato=heading,pagina_impresa_candidata=printed)
 if r['perfil']=='1':hist[ex,r['tema_candidato'],ident,heading]+=1
save(D/'preguntas.csv',data);save(D/'apartados-candidatos.csv',[dict(cuaderno=e,tema=t,apartado=k,titulo=h,apariciones=n) for (e,t,k,h),n in sorted(hist.items())])
save(D/'demanda-indicativa.csv',[dict(cuaderno=e,indicio=t,n=n,regla='superposición permitida; no es clasificación experta') for (e,t),n in sorted(cognitive.items())])
s=sum(bool(r.get('apartado_candidato')) for r in data)
p=D.parent/'04-ingenieria-inversa.md';text=p.read_text();at='## Plantillas, anulaciones y vigencia'
text=text.replace(at,f"**Apartados candidatos.** Se pudo asociar un epígrafe candidato a {s}/{len(data)} posiciones cruzando el archivo recuperado, el folio impreso leído al pie de la página y el índice del documento. Cuando faltaba el folio o el índice se dejó vacío. El número de página física y el de página impresa se conservan por separado. [Recuentos candidatos por apartado](oficial/apartados-candidatos.csv). El fichero por posición también distingue la clase cognitiva revisada de los indicios léxicos de demanda. [Recuentos de indicios cognitivos](oficial/demanda-indicativa.csv).\n\n"+at)
p.write_text(text);print('apartados candidatos',s)

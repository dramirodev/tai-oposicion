"""Reconstrucción desde las páginas y plantillas primarias. Python stdlib, Poppler."""
from pathlib import Path
from collections import defaultdict,Counter
import re,subprocess,hashlib,csv,unicodedata,statistics,json,sqlite3
T=Path('/Volumes/SSD/Google Drive/TEMARIO_OPOSICION');R=T/'RECURSOS/EXAMENES TAI'
W=Path('work/reinicio-oficial');O=Path('outputs/nueva');D=O/'oficial';D.mkdir(exist_ok=True,parents=True)
def norm(s):return ''.join(c for c in unicodedata.normalize('NFD',s.casefold()) if not unicodedata.combining(c))
def words(s):return re.findall(r'[a-z0-9]+',norm(s))
def sha(f):return hashlib.sha256(f.read_bytes()).hexdigest()
def read(f):
 s=subprocess.check_output(['pdftotext','-layout',str(f),'-']).decode()
 if s.strip():return s,False
 d=W/sha(f)[:12];return '\f'.join(x.read_text() for x in sorted(d.glob('p-*.jpg.txt'),key=lambda x:int(x.name.split('-')[1].split('.')[0]))),True
def write(f,items):
 with (D/f).open('w') as h:
  out=csv.DictWriter(h,list(dict.fromkeys(k for r in items for k in r)));out.writeheader();out.writerows(items)
def identify(p):
 gsi='GSI' in p.parts
 if gsi:year=p.parent.parent.name;acc='L' if p.parent.name=='ingreso-libre' else 'P';m='U'
 else:
  year=re.findall(r'20\d\d',p.parent.name)[-1];acc='L' if p.parent.name.startswith('ingreso') else 'P'
  s=p.name.lower();m='B' if re.search(r'(modelo|[-_])b(?:\b|_)',s) else 'A' if re.search(r'(modelo|[-_])a(?:\b|_)',s) else 'X' if '_ext' in s else 'II' if ('segundo' in s or '2jer' in s) else 'U'
 return ('GSI' if gsi else 'TAI')+'-'+year+'-'+acc+'-'+m
def extract_keys(p):
 s,_=read(p); events=[]
 regex=r'(?P<num>\d{1,3})\.\s*(?P<a>[abcd]\b|anulada\b)|(?P<sec>primera parte|segunda parte|(?:supuesto )?bloque (?:iii|iv)|supuesto (?:ii|i)\b|(?:preguntas de )?reserva\b|única\b)'
 for i,line in enumerate(s.splitlines()):
  if 'ejercicio' in line.lower() or 'cuerpo de' in line.lower():continue
  for m in re.finditer(regex,line,re.I):events.append((m.start(),i,m))
 cols=[]
 for x in sorted(set(x for x,i,m in events)):
  if not cols or x-cols[-1][-1]>15:cols.append([])
  cols[-1].append(x)
 section='P1';ans={}
 for col in cols:
  for x,i,m in sorted((e for e in events if e[0] in col),key=lambda e:(e[1],e[0])):
   if m['sec']:
    z=norm(m['sec']);section=section.split('R')[0]+'R' if 'reserva' in z else 'S2' if z.endswith((' ii',' iv')) else 'S1' if z.startswith(('segunda','bloque','supuesto')) else 'P1'
   else:
    k=(section,int(m['num']));assert k not in ans,(p.name,k)
    ans[k]=m['a'].upper()
 return ans
sources=defaultdict(dict);development=[]
for p in sorted(R.rglob('*.pdf')):
 if not ('INAP_plantillas_y_cuestionarios' in p.parts or 'GSI' in p.parts):continue
 if 'GSI' in p.parts and ('Segundo' in p.name or 'Tercer' in p.name):
  src,ocr=read(p)
  for j,page in enumerate(src.split('\f'),1):
   if page.strip():
    verbs=re.findall(r'\b(?:justifique|diseñe|indique|describa|explique|represente|realice|proponga|enumere|dibuje|compare|calcule)\b',page,re.I)
    development.append(dict(pdf=str(p),pagina=j,ocr=ocr,comienzo=' '.join(page.split())[:240],tareas=' / '.join(verbs)))
  continue
 e=identify(p);role='def' if 'plant' in p.name.lower() and 'def' in p.name.lower() else 'prov' if 'plant' in p.name.lower() else 'pdf'
 assert role not in sources[e],(e,p);sources[e][role]=p
web={};anchors=(W/'claves-web.txt').read_text().splitlines()
for pos in range(0,len(anchors),7):
 m=anchors[pos];keys={}
 for sec,s,n in zip(('P1','P1R','S1','S1R','S2','S2R'),anchors[pos+1:pos+7],(80,5,20,5,20,5)):
  s=s.replace(' ','');assert len(s)==n
  keys.update({(sec,i):('ANULADA' if a=='X' else a.upper()) for i,a in enumerate(s,1)})
 web[m]=keys
def parse(f,keys):
 txt,ocr=read(f)
 parsed={};section='P1';row=None;field=None;last=0;context=[]
 for j,page in enumerate(txt.split('\f'),1):
  if not page.strip():continue
  # Los cuadernos antiguos contienen la portada de instrucciones antes de arrancar la numeración.
  if j==1 and ('instrucciones cumplimentaci' in norm(page) or ocr):continue
  for raw in page.splitlines():
   line=raw.strip(); nline=norm(line)
   if not line or re.search(r'pagina\s+\d+\s+de',nline):continue
   if nline in ('primera parte','unica'):section='P1';last=0;row=None;continue
   h=re.fullmatch(r'(?:(?:supuesto(?: practico)?(?: bloque)?|bloque)\s+)(i{1,3}|iv|[l1]{1,3})\s*[.:]?',nline)
   if h:
    z=h[1].replace('l','i').replace('1','i');section='S2' if z in ('iv','ii') else 'S1';last=0;row=None;continue
   if re.fullmatch(r'(?:preguntas? de\s+)?reserva\s*[:.]?',nline):section=section.rstrip('R')+'R';last=0;row=None;continue
   if ocr:
    line=re.sub(r'^[|!¡“”\x22\x27;\[\]{}]+\s*','',line)
    line=re.sub(r'^[A-Za-z|!¡()%0-9]{1,3}\s{2,}(?=(?:[0-9]{1,3}[.,:]|[abcd]\)))','',line)
    line=re.sub(r'^[a-zA-Z]([abcd]\))',r'\1',line)
   match=re.match(r'^(\d{1,3})[.,:)]?\s+(.+)' if ocr else r'^(\d{1,3})\.\s+(.+)',line)
   if match and (section,int(match[1])) in keys and int(match[1])>last and int(match[1])<=last+4:
    last=int(match[1]);row={'pagina':j,'enunciado':match[2],'contexto_previo':' '.join(context)};context=[];parsed[section,last]=row;field='enunciado';continue
   if ocr and (row is None or 'd' in row) and re.match(r'^[^ ]{1,5}\s{4,}\S',line) and (section,last+1) in keys and not re.match(r'^[a-d]\)',line,re.I):
    row={'pagina':j,'enunciado':re.split(r'\s{4,}',line,1)[1]};last+=1;parsed[section,last]=row;field='enunciado';continue
   if row is None:continue
   if not ocr and section.startswith('S') and field=='d' and not raw[:1].isspace():context.append(line);continue
   if ocr: row.setdefault('_ocr',[]).append(line)
   for seg in re.split(r'\s+(?=[abcd]\)\s)',line):
    opt=re.match(r'^([abcd])\)\s*(.*)',seg,re.I)
    if opt:field=opt[1].lower();row[field]=opt[2]
    elif field:row[field]+=' '+seg
 if ocr:
  from lotes import ordinales
  for r in parsed.values():ordinales(r,r.get('_ocr',[]))
 return parsed,ocr
rows=[];deltas=[];docs=[]
for e,files in sorted(sources.items()):
 keys=extract_keys(files['def']) if 'def' in files else web[e[-1]]
 provisional=extract_keys(files['prov']) if 'prov' in files else {}
 assert not provisional or set(keys)==set(provisional),(e,len(keys),len(provisional))
 retrieved,ocr=parse(files['pdf'],keys)
 addr=str(files.get('def',''))
 if not addr:
  addr='https://sede.inap.gob.es/sites/sede/files/public/2026-10/PlantillarespuestasDefTAI-L-'+{'A':'A_G4WN8WY1M8','B':'B_35JU78W1JX','X':'EXTRAORDINARIO_1E0IFRJ3RK'}[e[-1]]+'_154AB89SD658.pdf'
 docs.append(dict(cuaderno=e,pdf=str(files['pdf']),sha256_pdf=sha(files['pdf']),plantilla_provisional=str(files.get('prov','')),plantilla_definitiva=addr,sha256_def=sha(files['def'] if 'def' in files else W/(e[-1]+'.pdf')),plazas=len(keys),origen_lectura='OCR' if ocr else 'digital'))
 for k,a in sorted(keys.items()):
  row=retrieved.get(k,{});qid=f'{e}-{k[0]}-{k[1]:02}';prev=provisional.get(k,'')
  if prev and prev!=a:deltas.append(dict(id=qid,antes=prev,despues=a,plantilla=addr))
  rows.append(dict(id=qid,cuaderno=e,seccion=k[0],numero=k[1],pagina=row.get('pagina',''),contexto_previo=row.get('contexto_previo',''),enunciado=row.get('enunciado',''),**{c:row.get(c,'') for c in 'abcd'},provisional=prev,definitiva=a,estado='OCR, revisar' if ocr else 'cuatro opciones' if all(row.get(c) for c in 'abcd') else 'revisar segmentación'))
 print(e,len(keys),len(retrieved),sum(all(q.get(c) for c in 'abcd') for q in retrieved.values()))
from lotes import amend, validar_opciones_visuales
amend(rows)
validar_opciones_visuales(rows)
write('cuadernos.csv',docs);write('desarrollo-gsi.csv',development);write('claves-modificadas.csv',deltas);write('preguntas.csv',rows)

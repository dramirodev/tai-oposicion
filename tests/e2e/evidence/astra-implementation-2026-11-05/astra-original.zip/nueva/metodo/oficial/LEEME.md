# Reproducir los informes 04 y 05

El archivo `oficial/reproduccion.zip` contiene las lecturas OCR de los escaneos y los tres PDF originales de claves definitivas de ingreso libre 2025. Cada cuestionario de Drive se vuelve a identificar por SHA-256. Los scripts Python de análisis requieren Poppler y SQLite con FTS5. No se contacta con Firebase.

Desde una carpeta de trabajo vacía, descomprimir el archivo para obtener `work/reinicio-oficial`. Preparar `outputs/nueva/banco/apartados.csv` con el índice de epígrafes de la auditoría. Copiar `ubicacion.py` a la carpeta de trabajo del resto de los scripts si se utiliza la copia en este directorio. Ejecutar en orden desde la raíz de trabajo:

```sh
python3 work/reinicio-oficial/analizar.py
python3 work/reinicio-oficial/informes.py
python3 work/reinicio-oficial/ubicacion.py
```

El primer comando relee los documentos, construye las filas, compara las plantillas e indexa la teoría. El segundo obtiene tablas y redacta los dos informes. El tercero añade epígrafes e indicios cognitivos. `raster.py` y `ocr.cjs` permiten repetir la extracción óptica inicial si se dispone de los datos españoles de Tesseract. Las lecturas incluidas permiten repetir los cálculos sin instalar un motor OCR.

Las correcciones de segmentación y las lecturas visuales se encuentran en `lotes.py`. En las tres plantillas web cuyas letras se dibujan como vectores, la lectura visual de las 405 casillas se conserva en `claves-web.txt`, con X para anulaciones. Las métricas de estilo se calculan exclusivamente en preguntas digitales de libre con clave definitiva válida, utilizando un modelo por llamamiento. La tabla por cuaderno distingue promoción interna y texto OCR para comparación.

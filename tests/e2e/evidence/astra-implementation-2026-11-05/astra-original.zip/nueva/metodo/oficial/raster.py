from pathlib import Path
import subprocess,hashlib
r=Path('/Volumes/SSD/Google Drive/TEMARIO_OPOSICION/RECURSOS/EXAMENES TAI')
for f in sorted(r.rglob('*.pdf')):
 if not ('GSI' in f.parts or 'INAP_plantillas_y_cuestionarios' in f.parts):continue
 t=subprocess.check_output(['pdftotext',str(f),'-'])
 if t.strip():continue
 d=Path('work/reinicio-oficial')/hashlib.sha256(f.read_bytes()).hexdigest()[:12];d.mkdir(exist_ok=True)
 (d/'source').write_text(str(f));subprocess.run(['pdftoppm','-r','185','-jpeg',str(f),str(d/'p')],check=True)

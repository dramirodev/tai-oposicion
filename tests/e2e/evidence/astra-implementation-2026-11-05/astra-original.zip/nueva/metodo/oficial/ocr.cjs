const {createWorker}=require('/Users/dramiro/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/tesseract.js')
const fs=require('fs'), path=require('path')
const dir=__dirname
const files=fs.readdirSync(dir,{withFileTypes:true}).filter(x=>x.isDirectory()).flatMap(d=>fs.readdirSync(path.join(dir,d.name)).filter(f=>f.endsWith('.jpg')).map(f=>path.join(dir,d.name,f)))
async function run(){const w=await createWorker('spa',1,{langPath:dir,gzip:false,cacheMethod:'none'});await w.setParameters({tessedit_pageseg_mode:'6',preserve_interword_spaces:'1'});while(files.length){const f=files.shift();const r=await w.recognize(f);fs.writeFileSync(f+'.txt',r.data.text)}await w.terminate()}
Promise.all(Array.from({length:3},run)).catch(e=>{console.error(e);process.exitCode=1})

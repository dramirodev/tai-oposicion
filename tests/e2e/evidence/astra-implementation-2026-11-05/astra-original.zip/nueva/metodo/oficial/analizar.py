from corpus import *
db=sqlite3.connect(':memory:');db.execute('create virtual table pags using fts5(t,doc unindexed,pag unindexed,tema unindexed)');vocab=Counter()
for f in sorted((T/'01_Temario').rglob('*.pdf')):
 if not re.search(' - Temario',f.name,re.I):continue
 topic=re.search(r'T\d\.\d\d',f.name)
 if not topic:continue
 for n,pg in enumerate(read(f)[0].split('\f'),1):
  if len(pg)<100:continue
  w=words(pg);vocab.update(set(w));db.execute('insert into pags values(?,?,?,?)',(' '.join(w),str(f),n,topic[0]))
for r in rows:
 s=norm(r['enunciado']);opts=[r[c] for c in 'abcd'];clave=r['definitiva'].lower()
 vocabq=sorted({w for w in words(s+' '+r.get(clave,'')) if len(w)>=3 and 0<vocab[w]<500},key=lambda w:(vocab[w],w))[:12]
 if vocabq:
  hit=db.execute('select doc,pag,tema from pags where pags match ? order by bm25(pags) limit 1',(' OR '.join(vocabq),)).fetchone()
  if hit:r.update(pdf_candidato=hit[0],pag_candidata=hit[1],tema_candidato=hit[2])
 tags={k for k,regex in {
 'interrogativa':r'[¿?]','seleccion inversa':r'\b(?:incorrect[oa]|fals[oa]|excepto|no (?:es|forma|pertenece|corresponde|se incluye|esta incluid[oa]))\b','negacion':r'\b(no|ni|nunca|sin)\b','excepcion':r'\b(salvo|excepto|excepcion)','norma citada':r'\b(ley|real decreto|constitucion|reglamento \(ue\)|rgpd|trebep)\b','articulo':r'\bart(?:iculo[s]?\b|\.)','condicion':r'\b(si|suponiendo|en caso de|siempre que|cuando)\b','absoluto':r'\b(nunca|siempre|unicamente|exclusivamente|ningun[oa]?)\b','definicion':r'\b(que es|entiende por|se define|hace referencia|significa el)','comparacion':r'\b(diferencia|frente a|en comparacion|a diferencia)','secuencia':r'\b(ordenad[oa]s?|secuencia|orden correcto)','instruccion':r'\b(comando|sentencia|fragmento de codigo|codigo siguiente|siguiente codigo|resultado de la ejecucion)\b'}.items() if re.search(regex,s)}
 r.update(marcas='|'.join(sorted(tags)),palabras=len(words(s)),palabras_alternativas=sum(len(words(o)) for o in opts))
 # 'perfil' incluye las dos familias de cuadernos de libre con lecturas digitales, y un solo modelo por llamamiento.
 r['perfil']=int(r['estado']=='cuatro opciones' and r['definitiva']!='ANULADA' and '-L-' in r['cuaderno'] and not r['cuaderno'].endswith('-B'))
sample_order=[('P1',3),('P1',28),('P1',50),('P1',72),('S1',3),('S1',12),('S2',3),('S2',12)]
# Tipo de distractor principal | demanda | tema | concepto. Codificación nueva de las cuatro opciones.
codings={
'TAI-2019-L-U':[
('CIF','recordar','T1.01','Composición del Tribunal Constitucional'),('CLA','reconocer definición','T2.02','SSD, expansión del acrónimo y tecnología'),('FAM','distinguir','T3.08','Finalidad de Ruby on Rails'),('CIF','recordar','T4.07','Prefijo multicast IPv6'),('INS','aplicar','T3.08','Atributo HTML obligatorio'),('INS','aplicar','T3.06','Clase Java final'),('CAL','calcular','T4.07','Hosts de una subred /21'),('CAL','calcular','T2.02','Capacidad útil de RAID')],
'TAI-2022-L-U':[
('FAM','recordar','T1.01','Circunscripción electoral'),('CLA','detectar excepción','T2.02','Conector USB y versión del protocolo'),('ANU','anulada','T3.07','REST'),('CLA','detectar excepción','T4.06','Construcción y propiedades de POF'),('FAM','distinguir','T3.06','Colecciones Java y duplicados'),('FAM','aplicar','T3.06','Tecnología Java para microservicio'),('CLA','reconocer definición','T4.02','Aprovisionamiento fino de almacenamiento'),('FAM','distinguir','T4.10','Bandas y generaciones WiFi')],
'TAI-2024-L-A':[
('CLA','detectar excepción','T1.01','Competencias del Rey y condición de autorización'),('CLA','reconocer definición','T3.02','Clave foránea'),('CIF','recordar','T3.09','Plazo de respuesta y cómputo de días'),('CLA','distinguir','T4.07','Capas y funciones OSI'),('INS','interpretar código','T3.04','INSERT INTO y literales'),('FAM','detectar excepción','T3.07','Descripciones de servicios web'),('ACT','aplicar','T4.09','Puerto 80 y redirección HTTPS'),('FAM','reconocer definición','T4.09','Amenaza persistente avanzada')],
'TAI-2025-L-A':[
('CLA','distinguir','T1.02','Diputación Permanente'),('FAM','reconocer definición','T2.02','Finalidad de IPP'),('FAM','reconocer definición','T3.07','WSDL y servicios relacionados'),('CLA','distinguir','T4.06','Conmutación de circuitos y paquetes'),('INS','aplicar','T3.04','Agregación SQL por programa'),('INS','interpretar código','T3.08','Sintaxis de un atributo XML'),('CAL','calcular','T4.07','División de /21 en cuatro subredes'),('INS','aplicar','T4.09','Sonda de conectividad TCP')],
'TAI-2025-L-X':[
('FAM','recordar','T1.02','Composición de las Cortes'),('CLA','distinguir','T3.08','Propiedades del objeto JSON'),('CLA','interpretar código','T3.08','Igualdad con coerción en JavaScript'),('CIF','recordar','T4.06','Puerto y transporte SIP'),('CLA','interpretar código','T3.08','Resultado de aplicar CSS al contenedor'),('FAM','aplicar','T3.09','Cabecera contra MIME sniffing'),('CLA','interpretar código','T4.01','Salida de hostname -f'),('INS','aplicar','T4.01','Crear sitio con cmdlet de Active Directory')]}
notes={
'CIF':('Permutar cantidades y condiciones','Las opciones combinan valores de la misma magnitud, unidades, plazos o condiciones.','Comprobar el par entero, desde la fuente y el hecho inicial hasta el plazo o destino.','Usar dos variantes equivalentes al redondear o al convertir unidades.'),
'CLA':('Modificar una cláusula','Las alternativas conservan parte de una definición o descripción y alteran una propiedad, un sujeto, un alcance o la relación entre ambos.','Subrayar la proposición que cambia y justificarla por separado.','Una excepción real puede volver correcta una segunda opción.'),
'FAM':('Elegir entre conceptos vecinos','Los distractores proponen categorías, herramientas, órganos o funciones próximas al objetivo.','Explicar por qué cada vecino serviría para otro problema concreto.','Introducir un término inventado identificable por su forma.'),
'INS':('Variar una instrucción','Las alternativas cambian una palabra reservada, un operador, sintaxis, argumento o nombre de comando.','Fijar versión y entorno. Ejecutar cuando sea viable y comparar efecto, permisos y entradas.','Dos sintaxis válidas que cumplen el mismo requisito.'),
'CAL':('Obtener un resultado a partir de datos','Las alternativas contienen resultados numéricos de un problema con parámetros explícitos.','Recalcular con una segunda derivación y explicar las unidades y descuentos.','Inventar a posteriori el error mental que llevó a un número.'),
'ACT':('Escoger una actuación en contexto','Se ofrecen distintas acciones operativas ante un objetivo y unas restricciones definidos.','Explicitar por qué una acción satisface simultáneamente las restricciones del supuesto.','Más de una actuación razonable cuando falta un detalle del entorno.')}
manifest={d['cuaderno']:d for d in docs};sample=[]
for r in rows:
 ex=r['cuaderno'];k=r['seccion'],r['numero']
 if ex in codings and k in sample_order:
  pat,cog,topic,concept=codings[ex][sample_order.index(k)];r.update(patron_revisado=pat,demanda_revisada=cog,tema_revisado=topic,concepto_revisado=concept)
  sample.append(dict(id=r['id'],cuaderno=ex,seccion=k[0],pagina=r['pagina'],patron=pat,demanda=cog,tema=topic,concepto=concept,clave=r['definitiva']))
write('preguntas.csv',rows);write('muestra-revisada.csv',sample)

from pathlib import Path
import json,re,csv,collections,statistics
p=Path('/Volumes/SSD/develop/tai-oposicion/public/data');groups=collections.defaultdict(list);items={}
for f in p.glob('T*.json'):
 for q in json.loads(f.read_bytes()):items[q['i']]=q
for s in json.loads((p/'supuestos.json').read_bytes()).values():
 for q in s['q']:items[q['i']]=q
for q in items.values():
 if len(q['a'])!=4:continue
 words=[len(re.findall(r'\w+',a)) for a in q['a']];m=max(words);val=(1/words.count(m) if words[q['c']]==m else 0)
 for k in ((q['o'],'todos'),(q['o'],q['t'])):groups[k].append(val)
with open('outputs/nueva/anexos/pista-longitud.csv','w') as f:
 w=csv.writer(f);w.writerow(['origen','tema','n','probabilidad_acierto_al_escoger_maximo']);w.writerows([*k,len(v),round(statistics.mean(v),5)] for k,v in sorted(groups.items()))
print([(k,len(v),round(statistics.mean(v),4)) for k,v in groups.items() if k[1]=='todos'])

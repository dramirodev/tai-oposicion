"""Distingue cita de autoría, página de teoría citada en el juicio y sentido del juicio."""
from pathlib import Path
from collections import Counter, defaultdict
import csv
import json
import re
import unicodedata

root = Path(__file__).resolve().parents[1] / 'banco'
def normal(text):
    return unicodedata.normalize('NFC',text).casefold()
with (root/'pdf-cotejados.csv').open() as source:
    docs = list(csv.DictReader(source))
by_name = defaultdict(list)
for doc in docs:
    by_name[normal(Path(doc['ruta']).name)].append(doc)
pattern = re.compile('('+ '|'.join(re.escape(name) for name in sorted(by_name,key=len,reverse=True))
                     + r')\s*[,;:]?\s*(?:p[áa]ginas?|p[áa]gs?\.?|pp?\.)\s*(\d+)')
fields = ['id','tema','origen','dictamen','cita_literal_principal','cita_literal_ampliada','pagina_de_teoria_en_dictamen','pagina_de_teoria_principal_en_dictamen']
with (root/'respaldo-por-id.csv').open('w',newline='') as out, (root/'inventario.jsonl').open() as source:
    writer = csv.DictWriter(out,fieldnames=fields)
    writer.writeheader()
    for row in map(json.loads,source):
        literal = [c['localizacion'] for c in row['citas'] if c.get('localizacion')]
        judged = row.get('juicio') or {}
        places=set()
        for name,pg in pattern.findall(normal(judged.get('evidencia',''))):
            cand=[d for d in by_name[name] if int(pg) in range(1,int(d['paginas'])+1)]
            if len(cand)==1:
                places.add(cand[0]['clase'])
        writer.writerow(dict(id=row['id'],tema=row['tema'],origen=row['procedencia'],dictamen=judged.get('estado',''),cita_literal_principal=int(any(c['clase']=='principal' for c in literal)),cita_literal_ampliada=int(bool(literal)),pagina_de_teoria_en_dictamen=int(bool(places)),pagina_de_teoria_principal_en_dictamen=int('principal' in places)))

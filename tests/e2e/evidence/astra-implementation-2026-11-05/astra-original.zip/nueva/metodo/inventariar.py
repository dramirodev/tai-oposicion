from pathlib import Path
import hashlib,csv,re,subprocess,collections,json,concurrent.futures
root=Path('/Volumes/SSD/Google Drive/TEMARIO_OPOSICION')
out=Path('outputs/nueva/anexos')
def extraer(p):
 rel=p.relative_to(root);n=p.name.lower();s=str(rel).lower();ext=p.suffix[1:].lower()
 cat='F';fuente='Material complementario local'
 if '.git' in rel.parts or p.name=='.DS_Store':cat='X';fuente='Metadatos de herramienta'
 elif rel.parts[0]=='01_Temario':
  if (ext=='pdf' and (' - temario' in n or n.startswith('b3t5_poo'))) or ext=='gdoc' and 'constituci' in n:cat='A';fuente='Temario facilitado'
  elif ext=='pdf' and re.search(r' - (test|ejercicios)',n):cat='E';fuente='Ejercicio temático'
 elif rel.parts[0]=='BANCO_PREGUNTAS':
  fuente='Archivo editorial derivado'
  if ext=='json' and ('banco' in n or 'supuestos' in n or 'literales' in rel.parts):cat='E'
 elif 'recursos/simulacros/' in s:cat='D';fuente='Simulacro de academia'
 elif 'recursos/examenes' in s and ext=='pdf':
  cat='C' if re.search('plant|respuesta',n) else 'B';fuente='Junta de Andalucía' if 'junta' in n else 'INAP/CPS según colección'
 h=hashlib.sha256();pag='';estado='leído';txt='';esc=[]
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 sha=h.hexdigest()
 if ext=='pdf':
  r=subprocess.run(['pdftotext','-layout',str(p),'-'],capture_output=True);txt=r.stdout.decode('utf8','replace');pages=txt.split('\f');pages=pages[:-1] if pages[-1]=='' else pages
  pag=len(pages);esc=[i for i,t in enumerate(pages,1) if len(t.strip())<40];estado='extraído' if not r.returncode else 'error extracción'
  (Path('work/textos')/(sha+'.txt')).write_bytes(r.stdout)
 m=re.search(r'T[1-4]\.\d\d',str(rel));cab=' '.join(txt.split()[:65]).lower()
 v=next((x for x in ('definitiva','provisional','alternativa','bis') if x in (cab if cat=='C' else n)),'')
 return dict(ruta=str(p),nombre=p.name,formato=ext,categoria=cat,procedencia=fuente,tema=m[0] if m else '',convocatoria=' / '.join(dict.fromkeys(re.findall(r'20[012]\d',s))) if cat in 'BC' else '',cuerpo=('GSI' if '/gsi/' in s else 'autonómico' if 'junta' in s else 'TAI') if cat in 'BC' else '',ejercicio=next((x for x in ['primer ejercicio','segundo ejercicio','tercer ejercicio','ejercicio único'] if x in cab),''),version=v,paginas=pag,sha256=sha,estado=estado,paginas_con_texto_escaso=' '.join(map(str,esc)))
paths=sorted(root.rglob('*'))
with concurrent.futures.ThreadPoolExecutor(6) as ex:rows=list(ex.map(extraer,[p for p in paths if p.is_file()]))
groups=collections.Counter(r['sha256'] for r in rows)
for r in rows:r['copias_binarias']=groups[r['sha256']]
with (out/'manifest.csv').open('w') as f:
 w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
(out/'directorios.txt').write_text('\n'.join(str(p) for p in paths if p.is_dir()))
print(len(rows),collections.Counter(r['categoria'] for r in rows))

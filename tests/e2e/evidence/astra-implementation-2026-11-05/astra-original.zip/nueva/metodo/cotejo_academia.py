from pathlib import Path
import csv,json,re,unicodedata,collections
p=Path('outputs/nueva'); bank=Path('/Volumes/SSD/Google Drive/TEMARIO_OPOSICION/BANCO_PREGUNTAS')
src=Path('/Volumes/SSD/develop/tai-oposicion/public/data')
q=[r for f in src.glob('T*.json') for r in json.loads(f.read_bytes())]+[r for s in json.loads((src/'supuestos.json').read_bytes()).values() for r in s['q']]
def norm(s):return unicodedata.normalize('NFC',s).casefold()
files={norm(r['nombre']):r for r in csv.DictReader((p/'anexos/manifest.csv').open()) if r['formato']=='pdf'}
raw={r['id']:r for name in ['banco_academia.json','banco_academia_revisar.json'] for r in json.loads((bank/name).read_bytes())['preguntas']}
cache={}
def parse(f):
 text=Path('work/textos',f['sha256']+'.txt').read_text()
 pos=text.upper().rfind('SOLUCIONES'); assert pos>=0
 n=text[:pos].count('\f')+1;header={};reserve=set();vals=collections.defaultdict(list)
 for k,page in enumerate(text[pos:].split('\f'),n):
  for line in page.splitlines():
   for m in re.finditer(r'primera parte|supuesto ii?\b|reserva\b',line,re.I):
    if m[0].lower()=='reserva':reserve.add(m.start())
    else:header[m.start()]={'primera parte':'P1','supuesto i':'S1','supuesto ii':'S2'}[m[0].lower()]
   for m in re.finditer(r'(?<!\S)(\d+)[.)]\s*([ABCD])\b',line,re.I):
    c=m.start(); left=[k for k in header if k<=c+1]; sec=header[max(left)] if left else 'P1'
    vals[(sec,any(abs(v-c)<=2 for v in reserve),int(m[1]))].append((m[2].upper(),k))
 return vals
rows=[]
for r in q:
 if r['o']!='A':continue
 f=files[norm(raw[r['i']]['fuente'])]; h=f['sha256']
 if h not in cache:cache[h]=parse(f)
 m=re.search(r'-(P1|S1|S2)(-R)?-(\d+)$',r['i'])
 matches=cache[h].get((m[1],bool(m[2]),int(m[3])),[])
 key,page=matches[0] if len(matches)==1 else ('','')
 rows.append([r['i'],f['ruta'],page,key,'ABCD'[r['c']],r.get('n','') if key!='ABCD'[r['c']] else ''])
with (p/'anexos/claves-academia.csv').open('w') as f:
 w=csv.writer(f);w.writerow(['id','fuente','pagina','clave_impresa','clave_app','nota_si_diverge']);w.writerows(rows)
print(len(rows),collections.Counter('sin clave' if not v[3] else 'coincide' if v[3]==v[4] else 'diverge' for v in rows))

import csv,json
from pathlib import Path
p=Path('outputs/nueva');q={x['id']:x for x in map(json.loads,(p/'banco/inventario.jsonl').open())}
s="""T3.09-20|Validada|9|El mínimo cambia al rebasar tres segundos; 5, 10 y 20 trasladan el umbral.
T3.09-20.v1|Validada|9|D distingue control independiente del global. A carece de esa condición, B restringe indebidamente a música y C dice lo contrario.
T3.09-20.v2|Ambigua|9|La C también es verdadera literalmente: un sonido de más de 10 segundos supera el umbral de 3. Para que sea falsa debe decir que el requisito empieza solo a partir de 10. Las demás son compatibles.
T3.09-24|Ambigua|12|Tres es el límite absoluto AAA (2.3.2); bajo 2.3.1 nivel A hay alternativa por umbral de destello. Citar solo la pauta no determina qué exigencia se pregunta.
T3.09-24.v1|Validada|12|D expresa el objetivo de la pauta. Teclado y velocidad de pulsación pertenecen a otras cuestiones, y la fatiga visual no define 2.3.
T3.09-24.v2|Validada|12|A y B distinguen expresamente las dos exigencias y C las ubica en la misma pauta. D introduce una autorización incondicional incompatible con ambas.
T4.03-23|Validada|13|220 indica servicio listo; las alternativas corresponden a 250, 421 y 221 en ese orden.
T4.03-23.v1|Validada|13|QUIT concluye normalmente con 221. Las otras respuestas significan indisponibilidad, saludo inicial o acción completada.
T4.03-23.v2|Validada|13|B asigna indisponibilidad al éxito 250. A, C y D respetan la tabla de códigos.
T4.08-20|Parcialmente respaldada|14|La clave 63 representa octetos por etiqueta. En ASCII coincide con caracteres; al hablar de nombres internacionalizados debe precisarse codificación.
T4.08-20.v1|Incorrecta|14|255 es el máximo de octetos de la representación en el protocolo. Una representación textual ASCII ordinaria ocupa hasta 253 caracteres sin punto final o 254 con él. Ninguna opción expresa ese máximo cuando se incluyen los puntos.
T4.08-20.v2|Validada|14|El punto final denota la raíz en un nombre absoluto. Ninguna de las otras opciones corresponde a la etiqueta vacía final."""
out=[]
for l in s.splitlines():
 id,st,pg,why=l.split('|');r=q['GEN-'+id];doc=next(x['localizacion']['pdf'] for x in r['citas'] if x.get('localizacion'))
 out.append(dict(id=r['id'],tema=r['tema'],estado=st,dictamen=why,ruta=doc,paginas=pg,clave=r['clave'],fuente_oficial=('https://www.w3.org/TR/WCAG22/' if id.startswith('T3') else 'https://www.rfc-editor.org/rfc/rfc5321#section-4.2.3' if id.startswith('T4.03') else 'https://www.rfc-editor.org/rfc/rfc1035#section-2.3.4')))
with (p/'anexos/lote-estandares.csv').open('w') as f:
 w=csv.DictWriter(f,fieldnames=list(out[0]));w.writeheader();w.writerows(out)

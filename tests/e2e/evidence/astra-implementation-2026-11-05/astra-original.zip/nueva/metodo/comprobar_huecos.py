"""Comprueba literalmente el contexto anterior/posterior a cada alternativa contra sus PDF."""
from pathlib import Path
import csv,json,re,unicodedata
p=Path('outputs/nueva');root=Path('/Volumes/SSD/Google Drive/TEMARIO_OPOSICION/01_Temario')
docs={r['ruta']:r['sha256'] for r in csv.DictReader((p/'anexos/manifest.csv').open())}
def canon(t):return ' '.join(re.findall(r'\w+',unicodedata.normalize('NFC',t).casefold()))
rows=[]
for q in map(json.loads,(p/'banco/inventario.jsonl').open()):
 parts=re.split(r'_{3,}',q['pregunta'])
 if len(parts)!=2:continue
 locs={(c['localizacion']['pdf'],c['localizacion']['pagina']) for c in q['citas'] if c.get('localizacion')}
 if not locs and q['pagina_busqueda']:locs.add((q['pagina_busqueda']['pdf'],q['pagina_busqueda']['pagina']))
 left=canon(parts[0]).split()[-5:];right=canon(parts[1]).split()[:5];hit=[]
 for doc,n in sorted(locs):
  t=canon(Path('work/textos',docs[str(root/doc)]+'.txt').read_text().split('\f')[n-1]);t=' '+t+' '
  for a,answer in zip('ABCD',q['opciones']):
   phrase=' '.join([*left,canon(answer),*right])
   if len(left+right)>=5 and ' '+phrase+' ' in t:hit.append((a,doc,n,phrase))
 letters=set(x[0] for x in hit)
 rows.append(dict(id=q['id'],clave=q['clave'],candidatos_literales=''.join(sorted(letters)),resultado='solo clave' if letters=={q['clave']} else 'otra opción o varias' if letters else 'sin frase literal',evidencia=json.dumps(hit,ensure_ascii=False)))
with (p/'anexos/huecos-contexto.csv').open('w') as f:
 w=csv.DictWriter(f,fieldnames=rows[0]);w.writeheader();w.writerows(rows)
from collections import Counter
print(len(rows),Counter(r['resultado'] for r in rows))

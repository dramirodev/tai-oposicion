from pathlib import Path
import json,csv,hashlib
q={x['i']:x for f in Path('/Volumes/SSD/develop/tai-oposicion/public/data').glob('T*.json') for x in json.loads(f.read_text())}
lines="""TAI2024B-P1-19|7|ACCEDA usa solo A–F. O, S y G invalidan las otras tres palabras.
P2024A-P1-R-02|7–10|111000010 en base 2 suma 256+128+64+2=450. Las restantes equivalen a 500, 500 y 263.
AT201-P1-02|8|3×16+11=59. Ningún otro entero coincide.
AT201-P1-06|9–10|53=6×8+5; 54, 55 y 64 octales representan 44, 45 y 52.
AT201-P1-57|7|DECAFE contiene seis dígitos hexadecimales; GEISER, EGEA y HABILITA contienen letras posteriores a F.
AS04-P1-25|8|11×256+10×16+1=2977. Solo C coincide.
AS04-P1-R-03|7–10|1010 y 0101 corresponden a A y 5. FR ni siquiera es hexadecimal; A3 y C4 cambian bits.
AS05G-P1-34|8–10|942=3×256+10×16+14=3AE. Los otros tres números tienen otros valores.
AS08B-P1-30|7–10|Agrupando de derecha a izquierda se obtiene 0010 1010 1011 1010 1001, es decir 2ABA9. Solo A conserva los cinco grupos.
L2019-P1-30|18–19|Visitar raíz antes de izquierda y derecha es preorden. Inorden intercala la raíz, postorden la deja al final.
L2025X-P1-22|18–19|D conserva raíz, izquierda y derecha; A permuta los hijos, B describe inorden, C postorden.
L2025X-P1-26|18|Con raíz en nivel 1 y cuatro niveles completos caben 1+2+4+8=15 nodos; ninguno de los demás números es el máximo.
AT203-P1-08|18–19|En preorden la primera visita es la raíz: 7. Las otras opciones aparecen después.
AT203-P1-09|18–19|En postorden la última visita es la raíz: 0. Las restantes aparecen antes.
AT203-P1-27|18|Si la raíz ocupa el nivel 1, el nivel i tiene como máximo 2 elevado a i−1 nodos. Conviene enunciar la convención: con raíz en nivel 0 la alternativa 2 elevado a i es válida.
AT203-P1-47|17–18|El grado máximo de un nodo de un árbol binario lleno de 15 nodos es 2. Uno impediría la ramificación; tres o cuatro violarían la definición de binario.
AT203-P1-49|18–19|Izquierda, raíz y derecha define inorden. Ninguna de las otras tres etiquetas identifica ese recorrido.
AS03-P1-71|35–37|La búsqueda dicotómica presupone orden para descartar media secuencia. El temario describe la versión recursiva. No es Quicksort ni existe garantía de ser siempre la más rápida.
AS03-P1-72|18–19|La raíz a divide inorden en b,d y e,c,f. El subárbol izquierdo produce d,b y el derecho e,f,c. El postorden completo d,b,e,f,c,a coincide solo con D.
AS06-P1-89|18|Un árbol completo de dos niveles admite tres nodos. Con cinco ocupa el tercero y no puede empezar el cuarto sin llenar antes los tres primeros.
AS08-P1-39|18–19|La lista inorden por sí sola admite varias formas de árbol y distintas raíces. Elegir un valor concreto exigiría una condición adicional.
AS11B-P1-40|18,37|La clave de ordenación gobierna las comparaciones. El orden de inserción altera la forma; preorden describe visitas y ningún nodo binario tiene tercer hijo.
AS12-P1-25|18,37|Visitar el subárbol de valores menores, después la raíz y finalmente el de mayores produce orden creciente. Los otros recorridos no garantizan esa secuencia.
L2025A-P1-73|29–30|Para 600 subredes hacen falta diez bits: 512 no bastan y 1024 sí. El prefijo mínimo desde /8 es /18; /19 satisface capacidad pero no minimalidad."""
m=list(csv.DictReader(open('outputs/nueva/anexos/manifest.csv')));rows=[]
for line in lines.splitlines():
 i,p,n=line.split('|');item=q[i];doc=next(x for x in m if x['tema']==item['t'] and x['nombre'].endswith(' - Temario.pdf'))
 rows.append(dict(id=i,tema=item['t'],estado='Ambigua' if i=='AT203-P1-27' else 'Validada',dictamen=n,ruta=doc['ruta'],sha256=doc['sha256'],paginas=p,clave='ABCD'[item['c']],enunciado=item['q'],opciones=json.dumps(item['a'],ensure_ascii=False)))
with open('outputs/nueva/anexos/lote-razonamiento.csv','w') as f:
 w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
print(len(rows))

"""Verifica el paquete de auditoría descomprimido con Python 3, sin red."""
import csv
import hashlib
import json
import re
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
BANK = ROOT / 'banco'
FIELDS = ('id', 'pregunta', 'opciones', 'clave', 'supuesto', 'extracto_visible', 'nota')


def read_csv(path):
    with path.open(encoding='utf-8', newline='') as source:
        return list(csv.DictReader(source))


def require(condition, message):
    if not condition:
        raise SystemExit(message)


def main():
    ledger = json.loads((BANK / 'dictamenes.json').read_text())
    pending_rows = read_csv(BANK / 'pendientes-semanticos.csv')
    pending = {row['id'] for row in pending_rows}
    signatures = read_csv(BANK / 'firmas-de-contenido.csv')
    by_id = {row['id']: row for row in signatures}
    ids = set()
    origins = Counter()
    grouped = Counter()
    with (BANK / 'inventario.jsonl').open() as source:
        for line in source:
            item = json.loads(line)
            key = item['id']
            require(key not in ids, f'ID duplicado: {key}')
            ids.add(key)
            origins[item['procedencia']] += 1
            if key in pending:
                continue
            entry = ledger.get(key)
            require(entry and entry == item.get('juicio'), f'Dictamen incoherente: {key}')
            require(all(entry.get(field) for field in ('metodo','evidencia','dictamen','estado')), key)
            payload = json.dumps([item[field] for field in FIELDS], ensure_ascii=False, separators=(',', ':'))
            signature = by_id.get(key, {})
            digest = hashlib.sha256(payload.encode()).hexdigest()
            require(signature.get('sha256_sobre_id_enunciado_opciones_clave_supuesto_extracto_nota') == digest, f'Huella diferente: {key}')
            require(signature['dictamen'] == entry['estado'] == item['estado'], f'Estado diferente: {key}')
            grouped[item['tema'], item['procedencia']] += 1
    require(len(pending_rows) == len(pending) and pending.isdisjoint(ledger), 'Pendientes duplicados o ya revisados')
    require(set(ledger) | pending == ids and set(by_id) == set(ledger) and len(signatures) == len(ledger), 'Cobertura incompleta')
    require(origins == {'O': 1049, 'A': 4106, 'G': 10923}, 'Censo diferente')
    totals = read_csv(BANK / 'cobertura-por-tema.csv')
    require(sum(int(row['total']) for row in totals) == len(ids), 'Total por temas diferente')
    for row in totals:
        require(grouped[row['tema'], row['origen']] == int(row['revisadas']), str(row))
    findings = read_csv(ROOT / 'anexos/incidencias-por-id.csv')
    require({r['pregunta'] for r in findings} == {k for k,v in ledger.items() if v['estado'] != 'Validada'}, 'Registro editorial incompleto')
    require(len({r['id'] for r in findings}) == len(findings), 'Incidencia duplicada')
    reports = sorted(ROOT.glob('[0-9][0-9]-*.md'))
    require(len(reports) == 10, 'Número de informes diferente')
    for report in [*reports, ROOT / 'README.md', ROOT / 'HANDOFF.md']:
        for link in re.findall(r'\]\(([^)]+)\)', report.read_text()):
            if not link.startswith(('https://','http://','/','#')):
                require((report.parent / link).exists(), f'Enlace local roto en {report.name}: {link}')
    print(f'{len(ids)} IDs únicos, {len(ledger)} dictámenes, {len(pending)} pendientes, {len(findings)} incidencias por ID, {len(reports)} informes.')


if __name__ == '__main__':
    main()

# 08 · Especificación del futuro generador

## Unidad editorial y condiciones de entrada

Seleccionar una afirmación evaluable dentro de un apartado, fijar la edición del PDF y guardar página física, pasaje, ruta y SHA-256. Separar las afirmaciones del enunciado de las presupuestas por las opciones. Un mismo concepto puede sostener varias operaciones cognitivas. Elegir la operación según el objetivo de aprendizaje y un ejemplo oficial del catálogo. Para una situación práctica conservar las premisas, datos, código y figuras que vio el candidato.

Probar primero este circuito con preguntas existentes: en AT203-P1-27, el nivel inicial del árbol determina cuál de dos fórmulas es correcta; en GEN-T4.07-08.v1, dos expresiones con nombres distintos pueden representar la misma unidad de datos. Un validador de cadenas diferentes aprobaría ambas estructuras. La evaluación semántica debe probar si dos opciones podrían ser verdaderas bajo la misma interpretación.

|Etapa|Producto verificable|Criterio de decisión|
|---|---|---|
|1–3. Elegir apartado, extraer y descomponer|Concepto y condiciones, pasaje con página, fecha de la norma o versión tecnológica|Suspender si falta la fuente, hay versiones incompatibles o se rebasa la profundidad TAI. Registrar brecha sin añadirla al programa.|
|4. Seleccionar patrón|Referencia a cuaderno, modelo, sección e ítem, más operación exigida|Explicar por qué la forma sirve para este concepto. Separar los ejemplos GSI y academia.|
|5–6. Enunciar y resolver|Problema autosuficiente, solución razonada y supuestos explícitos|Otra persona debe poder resolverlo sin ver las alternativas. Una condición omitida que altera la clave obliga a reescribir.|
|7. Escribir distractores|Tres errores distinguibles; condición bajo la que cada alternativa sería válida|Rechazar equivalentes, solapamientos que permitan dos claves, opciones absurdas y pistas exclusivas de la respuesta.|
|8–9. Verificar fuente y ambigüedad|Una prueba de la clave y tres refutaciones; consulta oficial fechada cuando corresponda|Contrastar excepciones, ámbito, temporalidad y versiones. Una segunda salida defendible bloquea el uso puntuable.|
|10–11. Validar estructura y duplicados|Cuatro opciones, clave válida, ID único, huella exacta y candidatos semánticos|Conservar signos, mayúsculas, operadores y unidades. Clasificar paráfrasis entre familias con revisión, incluida la repetición deliberada.|
|12–13. Estimar dificultad y explicar|Pasos de razonamiento; explicación de la clave y del error en cada distractor|Distinguir dato recordado, comparación y aplicación. Anotar dificultad estimada; la longitud del texto es insuficiente.|
|14–15. Evaluar y aprobar|Decisión editorial y revisión del lote firmado|Una persona autorizada adjudica las discrepancias. Antes de publicar, comparar claves y exclusiones con la versión anterior y ensayar lectura, puntuación y retirada en emulador.|

## Contrato compatible y publicación

Conservar QuestionRecord y su identificador histórico. Añadir un manifiesto editorial lateral asociado a ID y versión. Las preguntas antiguas parten de «sin revisar», incluso cuando la autoría indique que están verificadas. Una revisión desfavorable puede retirar una pregunta del conjunto puntuable conservando su transcripción histórica y los intentos ya realizados.

- **Identidad y procedencia.** ID, familia, alias, revisión de banco, origen y redactor o modelo conocido. Si se desconoce, dejar el dato vacío. Separar versión de fuente y versión de contenido.
- **Pruebas documentales.** Lista de evidencias con función (temario, norma, cuaderno, plantilla), ruta, hash, página, apartado, extracto, fecha de vigencia y condiciones. Reutilizar los campos de AcademyQuestionSectionManifest v2 para enlaces de academia; conservar por separado la respuesta impresa y cualquier corrección editorial.
- **Identidad de la corrección.** Mantener contentRevision para sus consumidores actuales. Incorporar una huella del enunciado, las opciones ordenadas, clave, contexto, material gráfico, nota y marca de exclusión. El cambio aislado de una clave debe invalidar su aprobación anterior.
- **Diseño y calidad.** Conceptos, patrón oficial con testigo, demanda cognitiva, premisas, distractor y justificación por opción, estado de vigencia, gravedad, revisor, fecha y motivo del cambio. Versionar tanto patrones como validadores.
- **Uso.** Modalidades para las que se ha aprobado, revisión del intento, exposición previa, variante, respuesta antes o después de ver la solución y dificultad estimada. Separar datos editoriales de estadísticas de alumnos y agregarlas solo con autorización.

Un lector anterior puede seguir consumiendo el DTO compacto. El publicador futuro debe comprobar que manifiesto y lote coinciden, preparar una versión completa antes de activarla y conservar la anterior para recuperación. Migración futura aditiva, primero en copia aislada; comprobar apertura de sesiones antiguas y reanudación tras cambio de clave.

## Validaciones y evidencia de aprendizaje

**Deterministas.** Rechazar claves fuera de rango, opción vacía, ID repetido, fuente desaparecida, material visual imprescindible ausente, reserva mal asignada o pregunta anulada elegible para nota. En problemas formales recalcular el resultado desde las premisas y comparar contra las cuatro alternativas. Incluir pruebas de negación, cambio de unidad, reordenación y cambio exclusivo de la clave.

**Documentales.** Reabrir la edición por hash y comprobar página y apartado. Una coincidencia literal solo prueba localización. Ante una discrepancia con una fuente oficial, conservar ambas formulaciones, fechas y decisión editorial.

**Semánticas.** Detectar implicación entre alternativas (una respuesta más general puede contener otra), dobles negaciones, entidades intercambiadas y diferencias sin efecto. La similitud y un segundo modelo sirven para encontrar candidatos; exigir un juicio independiente para incorporarlos.

**Revisión humana.** Resolver a ciegas y redactar por qué fallan las alternativas. Un segundo revisor arbitra discrepancias de alcance, vigencia o interpretación. Para evaluar el generador reservar pruebas completas y familias enteras; repartir sus variantes al azar entre entrenamiento y evaluación sobreestimaría la calidad.

**Solo con datos de estudiantes.** Medir acierto y blancos en primeras exposiciones, discriminación ítem-total corregida, elección de cada distractor y retención posterior en otra variante. Informar tamaño de muestra, modalidad, versión e incertidumbre. Separar aciertos tras consulta de solución. En estudio, pedir recuperación antes de mostrar feedback y volver a evaluar el concepto tras un intervalo. Los datos del catálogo no permiten fijar un intervalo óptimo ni dificultad empírica.

**Prueba de lote.** Elegir la alternativa con más palabras y repartir los empates uniformemente da un 51,03 % esperado en generadas, 27,06 % en academia y 29,15 % en oficiales del banco. Revisar opciones en las que solo la clave incluye matices justificativos. Comparar por tema y patrón tras la edición. [Datos recalculados](anexos/pista-longitud.csv).

La propuesta de separar intento y explicación se apoya en experimentos que compararon recuperación y reestudio, y en estudios que examinaron la retroalimentación tras elegir distractores. La investigación sobre espaciamiento relaciona la separación entre repasos con el horizonte de retención. Para trasladarla al examen TAI se debe medir el recuerdo posterior por concepto, con el mismo horizonte temporal en los grupos comparados. [Roediger y Karpicke, 2006](https://doi.org/10.1111/j.1467-9280.2006.01693.x) · [Butler y Roediger, 2008](https://doi.org/10.3758/MC.36.3.604) · [Cepeda et al., 2008](https://doi.org/10.1111/j.1467-9280.2008.02209.x).

<!-- RESULTADOS DEL CENSO -->
## Casos de aceptación para una primera prueba

Probar con AT407-P1-19 si el validador reconoce dos afirmaciones verdaderas sobre la cabecera TCP. Con AT407-P1-11 debe conservar el exponente al importar las alternativas para evitar que 2 elevado a 16 se lea como 216. En AS08B-P1-37 debe exigir que el alumno pueda consultar el grafo necesario antes de habilitar la puntuación. Conservar las cuatro opciones, la decisión y la fuente en la prueba y resolver cada caso antes de abrir un lote de generación. [Dictámenes de referencia](banco/dictamenes.json).

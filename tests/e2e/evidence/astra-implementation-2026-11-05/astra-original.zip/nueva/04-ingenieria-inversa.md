# 04 · Cómo preguntan los exámenes oficiales TAI y GSI

Se reconstruyeron **2765 posiciones de plantilla** de 26 cuadernos. Cada posición conserva la convocatoria, vía, modelo, parte, número, clave y ruta al PDF. Se distinguieron 1715 apariciones TAI y 1050 GSI. Los dos supuestos, las reservas y los modelos A/B cuentan aquí como posiciones publicadas. Un estudiante resuelve sólo el recorrido que permite su convocatoria.

## Lectura y depuración

La unidad del perfil TAI es la pregunta publicada en un cuaderno de ingreso libre. Se incluyó un modelo por llamamiento y se excluyeron las anuladas. Los años 2019, 2022, 2024 y 2025 aportan cinco cuadernos digitales contando el extraordinario 2025 de forma separada. GSI se comparó con los cuatro primeros ejercicios digitales de ingreso libre de las mismas convocatorias. Promoción interna, segundos/terceros ejercicios, copias, Andalucía y academia se mantienen fuera de esos perfiles. Los años identifican convocatorias, aunque la prueba se celebrase después.

| Cuaderno | Posiciones | Con enunciado | 4 opciones | Anuladas | N del perfil |
|---|---|---|---|---|---|
| GSI-2018-L-U | 105 | 105 | 105 | 1 | 0 |
| GSI-2018-P-U | 105 | 105 | 105 | 1 | 0 |
| GSI-2019-L-U | 105 | 105 | 105 | 1 | 104 |
| GSI-2019-P-U | 105 | 105 | 105 | 1 | 0 |
| GSI-2022-L-U | 105 | 105 | 105 | 4 | 101 |
| GSI-2022-P-U | 105 | 105 | 105 | 3 | 0 |
| GSI-2024-L-U | 105 | 105 | 105 | 4 | 101 |
| GSI-2024-P-U | 105 | 105 | 105 | 1 | 0 |
| GSI-2025-L-U | 105 | 105 | 105 | 3 | 102 |
| GSI-2025-P-U | 105 | 105 | 105 | 2 | 0 |
| TAI-2018-L-II | 70 | 70 | 70 | 1 | 0 |
| TAI-2018-L-U | 105 | 105 | 105 | 0 | 0 |
| TAI-2018-P-U | 85 | 85 | 85 | 1 | 0 |
| TAI-2019-L-U | 135 | 135 | 135 | 0 | 135 |
| TAI-2019-P-U | 85 | 85 | 85 | 0 | 0 |
| TAI-2022-L-U | 135 | 135 | 135 | 6 | 129 |
| TAI-2022-P-U | 85 | 85 | 85 | 0 | 0 |
| TAI-2024-L-A | 135 | 135 | 135 | 4 | 131 |
| TAI-2024-L-B | 135 | 135 | 135 | 4 | 0 |
| TAI-2024-P-A | 85 | 85 | 85 | 0 | 0 |
| TAI-2024-P-B | 85 | 85 | 85 | 0 | 0 |
| TAI-2025-L-A | 135 | 135 | 135 | 2 | 133 |
| TAI-2025-L-B | 135 | 135 | 135 | 2 | 0 |
| TAI-2025-L-X | 135 | 135 | 135 | 0 | 135 |
| TAI-2025-P-A | 85 | 85 | 85 | 1 | 0 |
| TAI-2025-P-B | 85 | 85 | 85 | 1 | 0 |

Los cuadernos escaneados de 2018 se rasterizaron a 185 ppp y se pasaron por OCR español. Se reanclaron 34 posiciones cotejando número y orden, y se transcribieron visualmente las cuatro alternativas de las 23 filas que seguían incompletas. Se comprobó además la distinción entre las preguntas 6 y 7 de promoción interna TAI (página física 2). Quedaron cuatro casillas por cada una de las 2.765 posiciones. El resto de los textos OCR sigue pendiente de cotejo visual individual antes de reutilizarse. Cuatro opciones reconocidas es una condición estructural. Para fórmulas, tablas, código y figuras se debe abrir la página original. En los supuestos de 2025 también hay instrucciones entre preguntas.

## Diferencias entre convocatorias

| Cuaderno comparable | N | Palabras por enunciado¹ | Palabras por opción² | Inversa³ | Norma³ | Condición³ | Excepción³ |
|---|---|---|---|---|---|---|---|
| GSI-2019-L-U | 104 | 19.0 | 8.9 | 6 | 17 | 6 | 0 |
| GSI-2022-L-U | 101 | 17 | 9.9 | 18 | 12 | 5 | 1 |
| GSI-2024-L-U | 101 | 15 | 9.6 | 16 | 11 | 8 | 1 |
| GSI-2025-L-U | 102 | 20.0 | 11.5 | 5 | 14 | 13 | 0 |
| TAI-2019-L-U | 135 | 23 | 8.3 | 12 | 15 | 18 | 0 |
| TAI-2022-L-U | 129 | 18 | 6.4 | 21 | 10 | 8 | 1 |
| TAI-2024-L-A | 131 | 19 | 9.8 | 15 | 15 | 12 | 0 |
| TAI-2025-L-A | 133 | 25 | 8.5 | 5 | 19 | 9 | 2 |
| TAI-2025-L-X | 135 | 22 | 7.5 | 9 | 15 | 10 | 1 |

¹ Mediana. ² Media de las cuatro alternativas. ³ Conteos multietiqueta por expresiones literales. «Selección inversa» requiere una señal del tipo *incorrecta*, *falsa*, *excepto* o negación próxima a un verbo predefinido. «Norma» exige mención explícita de legislación, Constitución o reglamento. «Condición» recoge entre otras *si* y *cuando*. Estas reglas favorecen la reproducibilidad y pueden omitir paráfrasis o contar negaciones subordinadas. Enunciados jurídicos sin cita y técnicos con cita de ley impiden interpretar la columna «norma» como una partición jurídico/técnica.

En el perfil TAI (N=663) las claves definitivas se reparten así: B 176, C 175, A 168, D 144. En GSI (N=408): C 118, B 112, A 107, D 71. Su utilidad en esta auditoría es detectar errores de extracción. Los conteos no predicen respuestas futuras. El anexo por cuaderno conserva el resto de las marcas y los denominadores.

## Demanda y diferencias entre los bloques

Para interpretar el contenido se leyeron las cuatro opciones de ocho posiciones fijas de cada uno de los cinco cuadernos TAI del perfil: preguntas 3, 28, 50 y 72 de la primera parte y 3 y 12 de ambos supuestos. Se conservaron 40 filas y se excluyó una anulada del denominador de patrones. La selección por posiciones facilita réplica y cubre ambos supuestos, pero favorece materias según el orden del cuaderno. No estima prevalencias poblacionales.

| Bloque asignado en la muestra | N válido | Demandas estimadas | Ejemplo y concepto |
|---|---|---|---|
| T1 | 5 | recordar 3, detectar excepción 1, distinguir 1 | TAI-2019-L-U-P1-03 · Composición del Tribunal Constitucional |
| T2 | 4 | reconocer definición 2, calcular 1, detectar excepción 1 | TAI-2019-L-U-P1-28 · SSD, expansión del acrónimo y tecnología |
| T3 | 16 | aplicar 5, interpretar código 4, distinguir 3, reconocer definición 2, recordar 1, detectar excepción 1 | TAI-2019-L-U-P1-50 · Finalidad de Ruby on Rails |
| T4 | 14 | distinguir 3, aplicar 3, recordar 2, calcular 2, reconocer definición 2, detectar excepción 1, interpretar código 1 | TAI-2019-L-U-P1-72 · Prefijo multicast IPv6 |

En el bloque I se observa la distinción entre órganos, condiciones legales y cifras. En tecnología básica se alternan identificación de un dispositivo y comparación de propiedades. En desarrollo se pide reconocer el efecto exacto de SQL, XML, CSS o Java. En infraestructura se pasa del prefijo o puerto memorizado al cálculo de hosts o a probar conectividad bajo requisitos expresos. El caso narrado no implica necesariamente razonamiento complejo: unas preguntas del supuesto se resuelven recordando un nombre; otras dependen de utilizar los datos de la red. La clasificación cognitiva es un juicio sobre la tarea. Dificultad, discriminación y funcionamiento efectivo de los distractores requieren respuestas reales por ítem.

## Alcance transferible de GSI

En el primer ejercicio hay formatos compartidos. GSI-2019-L-U-P1-03 combina mínimos y máximos parlamentarios, mientras TAI-2019-L-U-P1-03 combina el total de miembros y los órganos de propuesta. GSI-2019-L-U-P1-28 ordena capas OSI; TAI-2024-L-A-P1-72 exige reconocer una proposición sobre el mismo modelo. En GSI-2025-L-U-P1-50 se diagnostica el defecto de verificabilidad de un requisito. En su segundo ejercicio de 2024 se pide diseñar y justificar arquitectura y medidas de seguridad. El cuaderno de desarrollo evalúa producción de una solución. Su formato se segrega en el inventario por página.

| Ejemplo GSI 2025 libre | Dictamen de transferencia | Fundamento |
|---|---|---|
| GSI-2025-L-U-P1-03 | directamente aplicable | Duración y término del mandato constan en T1.02, página 8. |
| GSI-2025-L-U-P1-28 | directamente aplicable | T2.05, página 26, describe Cassandra en la clasificación NoSQL. |
| GSI-2025-L-U-P1-50 | requiere adaptación | Evaluar la verificabilidad de un requisito con criterios objetivos. La página candidata recuperada no demuestra ese criterio. |
| GSI-2025-L-U-P1-58 | fuera del alcance localizado | El nombre de producto Presidio se buscó en los 44 PDF de teoría indexados (2.460 páginas), sin coincidencia. La materia general de protección de datos sí pertenece al programa. |
| GSI-2025-L-U-P1-72 | requiere adaptación | El principio de acceso está en T3.09. La página candidata trata una pauta concreta de teclado y resulta insuficiente para justificar la definición íntegra. |
| GSI-2025-L-U-P1-80 | directamente aplicable | T4.01, páginas 72–73 de la versión alternativa, explica Ansible, playbook y tareas declarativas. |
| GSI-2025-L-U-P1-85 | directamente aplicable | T4.04, página 43, identifica la seguridad basada en usuarios y USM en SNMPv3. |
| GSI-2025-L-U-P1-90 | demasiado profunda para traslado directo | T4.10, página 36, enumera protocolos de estado de enlace. La pregunta exige además justificar una preferencia operativa y su relación con el stack IP. |

Las ocho decisiones son una muestra dirigida. El resto recibe una ruta de búsqueda por BM25 cuando existen términos informativos. Se indexaron páginas de PDFs de teoría llamados « - Temario», se tomaron hasta 12 términos de baja frecuencia del enunciado y la respuesta y se recuperó la mejor página. La ausencia de un producto en esa búsqueda señala una brecha documental para comprobar. El apartado o el número de conceptos carece de equivalencia única para muchos ítems. Se entrega el concepto revisado en la muestra, y el tema candidato separado en el resto. El análisis no transforma una coincidencia léxica en validación editorial.

**Apartados candidatos.** Se pudo asociar un epígrafe candidato a 2726/2765 posiciones cruzando el archivo recuperado, el folio impreso leído al pie de la página y el índice del documento. Cuando faltaba el folio o el índice se dejó vacío. El número de página física y el de página impresa se conservan por separado. [Recuentos candidatos por apartado](oficial/apartados-candidatos.csv). El fichero por posición también distingue la clase cognitiva revisada de los indicios léxicos de demanda. [Recuentos de indicios cognitivos](oficial/demanda-indicativa.csv).

## Plantillas, anulaciones y vigencia

El contraste provisional/definitiva registró **25 modificaciones de posición TAI** contando los modelos de examen por separado. En 2025 libre se descargaron las tres definitivas de la publicación oficial y se leyeron las 405 casillas. El resultado para los modelos A y B fue la anulación de la primera parte 20/A y 17/B y de la reserva 2 del supuesto I en ambos. El extraordinario conservó sus claves provisionales. El CSV incluye todos los cambios, fuentes y huellas SHA-256 de las plantillas en el índice de cuadernos. La clave de una prueba histórica tampoco acredita vigencia de su contenido en 2026. [Publicación del INAP, 30/10/2026](https://laadministracionaldia.inap.es/noticia.asp?id=1520923).

## Anexos

[Cuadernos y fuentes](oficial/cuadernos.csv) · [Anatomía por posición](oficial/preguntas.csv) · [Estadísticas por convocatoria](oficial/estadisticas-cuaderno.csv) · [Temas candidatos](oficial/distribucion-temas-candidatos.csv) · [Muestra revisada](oficial/muestra-revisada.csv) · [Cambios de plantilla](oficial/claves-modificadas.csv) · [Transferencia GSI](oficial/transferencia-GSI.csv) · [Ejercicios de desarrollo GSI](oficial/desarrollo-gsi.csv).

[Scripts y procedimiento de reproducción](metodo/oficial/LEEME.md) · [Material de reproducción, incluidas las plantillas definitivas de 2025](oficial/reproduccion.zip).

<!-- RESULTADOS DEL CENSO -->
## Correspondencia entre los cuadernos y los IDs activos

Los 1.049 IDs oficiales activos tienen juicio individual y se contrastaron con las apariciones de la aplicación. La matriz de cuadernos incluye también posiciones fuera del banco, modelos repetidos, reservas y GSI. El perfil descriptivo de 663 posiciones TAI y 408 GSI y la muestra cognitiva de 39 preguntas válidas conservan sus propios denominadores. Tras el cotejo visual de 30 casos dirigidos, se resolvieron también los tres casos restantes del cruce de 33 apariciones discrepantes, incluidos el alias de Agenda 2030 y una errata impresa en OQL. [Detalle por posición](oficial/discrepancias-cotejadas.csv). Otras transcripciones escaneadas requieren una lectura visual antes de su reutilización literal.

| Origen | Revisadas | Validadas | Parciales | Ambiguas | Incorrectas | Posible obsolescencia | Sin respaldo |
|---|---:|---:|---:|---:|---:|---:|---:|
| Oficial | 1.049 | 771 | 197 | 39 | 14 | 13 | 15 |

[Contraste por aparición, modelo y plantilla](banco/contraste-plantillas.csv) · [Dictámenes por ID](banco/dictamenes.json).

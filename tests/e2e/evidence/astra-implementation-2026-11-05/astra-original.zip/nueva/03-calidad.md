# 03 · Qué respaldo y qué calidad se han podido demostrar

Se han emitido **16.078 dictámenes individuales**. Quedan **0 IDs** en la cola. [Dictámenes y evidencia](banco/dictamenes.json) · [Pendientes por ID](banco/pendientes-semanticos.csv).

«Validada» es el juicio documental de esta auditoría. La aprobación humana para publicación exige una segunda revisión identificada. La ausencia de una cita recuperada no basta para afirmar que el contenido queda fuera del programa. Los porcentajes de incidencias en la muestra dirigida no se extrapolan al conjunto.

### Qué se cotejó de forma independiente

- **Cobertura documental.** Se buscaron todas las citas de autoría en **51 PDF y 2.747 páginas con texto**. Se recuperaron 20.888 de 23.299 fragmentos. Al menos una cita llevó a 10.090 IDs (62,76 % de todo el banco; 92,37 % de las generadas). De ellos, 8.891 se vincularon a PDF principales (55,30 % del total) y 1.199 únicamente a resúmenes de T3.06. En 8.950 se recuperaron todas las citas. Los tests y plantillas nunca se contabilizan como página de temario. [Documentos y hashes](banco/pdf-cotejados.csv).
- **Método.** Se extrajo texto con `pdftotext -layout`, conservando páginas físicas, caracteres, mayúsculas y signos. Para comparar se aplicó NFC y se retiraron espacios y guiones blandos. Los fragmentos de menos de 25 caracteres se excluyeron de este cálculo para reducir coincidencias accidentales. En ausencia de coincidencia se propusieron páginas por vocabulario compartido, ponderando términos raros dentro del tema. La consulta usa enunciado y clave; en consecuencia, una página propuesta así es una ayuda sesgada de búsqueda. El ID, cita original, localización y número de coincidencias quedan registrados individualmente. En un PDF con secciones múltiples por página, el epígrafe inferido requiere revisión editorial. [Proceso reproducible](banco/procesar.py).
- **Primer corte de 206 dictámenes.** Se eligió una generada por tema entre las que tenían cita localizada y una de academia por tema entre las que tenían el texto de la clave en una página candidata, ordenando dentro del estrato por SHA-256 de la semilla textual y el ID. Se sumaron 24 resoluciones matemáticas o algorítmicas, 13 lecturas sobre reformas constitucionales, 12 de estándares técnicos, 30 sobre Unix, una comprobación visual de procedencia y dos decisiones de plantilla definitiva y 53 contrastes de puertos de red contra IANA y RFC. AT408-P1-46 se revisó en academia y en puertos; se conservan ambas comprobaciones. Suman 206 IDs distintos. Las semillas de los dos primeros lotes son `auditoria-nueva-20261105:` y `academia-20261105:`. La selección favorece preguntas documentables; los restantes lotes priorizan riesgos concretos. [Resoluciones](anexos/lote-razonamiento.csv) · [Reformas](anexos/lote-reformas.csv) · [Estándares](anexos/lote-estandares.csv) · [Unix](anexos/lote-tecnico.csv) · [Puertos, protocolos y transportes](anexos/lote-puertos.csv).
- **Plantillas.** Para las 1.049 oficiales se cruzaron 1.665 apariciones declaradas con los cuadernos y definitivas de la extracción independiente. En 1.626 coincide el texto de la alternativa correcta al normalizar letras, números y signos; seis apariciones de dos IDs han sido anuladas; 33 dieron diferencias en los textos que requieren interpretación. La letra coincide en 32 de estas 33. El número de sumas o símbolos que se pierde al normalizar código impide usar esta métrica como verificación íntegra de expresiones. [Cruce de apariciones](banco/contraste-plantillas.csv).

### Errores que cambian lo que aprende el estudiante

| Prioridad | Pregunta | Evidencia e impacto |
|---|---|---|
| P0 | GEN-T1.01-05 y .v1 | La fuente anterior enumera tres reformas y la clave de .v1 penaliza «cuatro». La cuarta reforma entró en vigor el 20 de mayo de 2026. La variante base carece de una lista completa. [BOE](https://www.boe.es/buscar/doc.php?id=BOE-A-2026-10881). |
| P0 | AT107-P1-22 | La clave y el temario imprimen «no quiere el apoyo permanente». La ley establece que la persona «no requiere el apoyo permanente». El cambio convierte una necesidad objetiva en preferencia. [Ley 39/2006, art. 26](https://www.boe.es/buscar/act.php?id=BOE-A-2006-21990#a26). |
| P0 | AT204-P1-33 | La clave ofrece Peppermint OS como distribución basada actualmente en Ubuntu. La p. 51 del temario de sistemas operativos y el propio proyecto sitúan la base en Debian; el proyecto también ofrece Devuan. Debe fijarse la versión si se pretende preguntar el dato histórico. [Peppermint OS](https://peppermintos.com/about/). |
| P0 | AT307-P1-34 | Se atribuye WS-Policy a OASIS tanto en la pregunta como en T3.07, p. 26. WS-Policy 1.5 es una recomendación W3C; mezclarla con WS-SecurityPolicy enseña otra autoría. [W3C](https://www.w3.org/TR/ws-policy/). |
| P0 / exclusión ya operativa en una reserva | L2025A-P1-20 y L2025A-S1-R-02 | Ambas tienen C en el banco y anulación definitiva de acceso libre. Solo la segunda ya está marcada `np=1`. Conservar el original y explicar la decisión histórica en estudio. [Fuente por modelo](oficial/claves-modificadas.csv). |
| P0 | GEN-T4.08-20.v1, AT204-P1-41 y AS12B-S2-08 | Las resoluciones independientes de DNS y Unix identifican claves o premisas incompatibles con las normas y el comportamiento de los comandos. El lote conserva las cuatro opciones, la página y el motivo exacto. [DNS](anexos/lote-estandares.csv) · [Unix](anexos/lote-tecnico.csv) · [Puertos, protocolos y transportes](anexos/lote-puertos.csv). |
| P1 | GEN-T4.07-08.v1 | T4.07, p. 6, iguala SDU(n−1) con PDU(n). Las opciones C y D solo sustituyen una expresión por su igual. No basta distinguir cadenas diferentes para garantizar una respuesta única. |
| P1 | GEN-T2.03-32 y GEN-T3.05-83.v2 | En la primera, raíz 1 depende de la convención de nivel del PDF, frente al cero cuando se cuenta la distancia a la raíz. En la segunda, llamar a un método abstracto no demuestra por sí solo el patrón Template Method; falta el esqueleto del algoritmo. [NIST, profundidad de un nodo](https://xlinux.nist.gov/dads/HTML/depth.html). |
| P1 | L2018-P1-06 | El banco asocia la pregunta del año de la Agenda 2030 a P2018-P1-06. La p. física 2 del PDF de promoción interna muestra la pregunta de transparencia en el número 6 y la de Agenda 2030 en el 7. La respuesta de la pregunta canónica de libre sigue siendo 2015. |
| P1 | GEN-T1.01-08.v2 | Al preguntar por una sola afirmación incorrecta, ofrece tanto «una de las tres reformas» como la publicación en 2011. Ambas son falsas en el corte de la auditoría. [Comparación de versiones y BOE](anexos/lote-reformas.csv). |

**Confusión entre servicio, cliente y transporte.** En AT408-P1-44 la clave incluye puertos de cliente como si fueran puertos de escucha del servidor DHCP. El servicio DHCPv4 recibe en 67/UDP y el cliente en 68/UDP; en v6 corresponden 547/UDP al servidor y 546/UDP al cliente. En GEN-T4.09-77 tanto L2F como L2TP pueden satisfacer el uso de 1701/UDP y la multiplexación de sesiones. GEN-T4.03-32.v2 trata como imposible cifrar IMAP en el puerto 143; STARTTLS ofrece justamente esa posibilidad. El lote conserva las opciones y las normas que permiten distinguir entre transporte, rol y modo de establecimiento de TLS. [53 contrastes individuales](anexos/lote-puertos.csv).

### Qué significa la repetición para el aprendizaje

El banco incluye 3.641 familias intencionadas. El estudiante puede recordar la respuesta de una variante casi idéntica sin dominar su aplicación en un escenario nuevo. Un análisis de repaso espaciado debe seguir los intentos por ID **y** por familia, distinguiendo exactitud inmediata de recuerdo posterior. Esta auditoría no usó historiales individuales y por tanto no estimó parámetros de dificultad, discriminación, rendimiento en el tiempo ni efectividad causal del repaso.

Hay nota editorial en las 1.049 oficiales, en 274 de las 4.106 de academia y en 13 generadas. Las 10.923 generadas aportan extracto textual. Para 3.832 preguntas de academia faltan tanto nota como extracto. La presencia de una cita puede ayudar al estudiante a recuperar un dato, pero no aclara automáticamente por qué un distractor como PDU(n) equivale a la clave. Conviene explicar también la primera alternativa plausible que probablemente escogería un estudiante con una confusión concreta.

**Cierre de cobertura.** Se conciliaron los 16.078 IDs. La siguiente lectura corresponde a adjudicación editorial de las incidencias ya identificadas.

Las 33 discrepancias de extracción se cotejaron también por apariencia publicada. La pregunta 18 de promoción interna de 2018 imprime Android 9.0, aunque el OCR leyó 2.0. En el modelo B libre de 2024, la opción C de la pregunta 28 repite «de datos.» en el propio PDF. [Resultado del cotejo de las 33 apariciones](oficial/discrepancias-cotejadas.csv).

### Dos preguntas casi idénticas pueden necesitar claves distintas

Un segundo control agrupó preguntas con las mismas cuatro alternativas (permitiendo permutación), pero con respuestas textuales diferentes. Comparó los enunciados conservando mayúsculas y operadores, y recuperó **158 pares** con similitud de caracteres ≥0,82. El primer par cambia el exponente 24 por 21 y con él la unidad correcta; otro cambia el tipo de C# `byte` por `sbyte`. Estos casos ilustran por qué una comparación aproximada es una alerta y por qué eliminar por semejanza puede destruir una distinción pedagógica. [Los 158 pares por ID](anexos/claves-distintas-opciones-iguales.csv).


### Contraste ciego auxiliar

Un segundo piloto, con Qwen2.5-7B-Instruct en este Mac, recibió el enunciado, las cuatro alternativas en orden aleatorio y dos pasajes del temario. Se ocultó la clave. En 13 de 18 preguntas previamente validadas eligió la respuesta publicada. También coincidió con la clave en 2 de las 5 ya declaradas incorrectas. Incluso cuando devolvió una cita literal, a veces interpretó mal la negación o repitió la etiqueta en vez de razonar. La muestra es dirigida y el modelo solo se usa como segunda lectura para seleccionar discrepancias. El ensayo adicional produjo 131 propuestas. Se detuvo el proceso local tras comprobar los falsos positivos y se excluyeron las 131 del recuento. [Calibración por ID](anexos/calibracion-local.csv).

### Cobertura comprobable por tema

[Recuento de revisadas y pendientes en cada tema y origen](banco/cobertura-por-tema.csv) · [Huella de contenido de cada pregunta revisada](banco/firmas-de-contenido.csv) · [Cambios de dictamen o evidencia](anexos/historial-dictamen.json) · [Segundas lecturas del mismo ID](anexos/dobles-lecturas.json). Se cotejaron los enunciados, opciones en orden y claves con los 16.078 registros del checkout antes de generar este corte. Los juicios se deduplican por el ID que ve el estudiante.

<!-- RESULTADOS DEL CENSO -->
## Cómo interpretar el dictamen de cada pregunta

La revisión valora si la clave puede defenderse con la redacción y las alternativas que ve el estudiante. Una plantilla acredita la respuesta que publicó su autor. Una cita literal permite localizar un pasaje. Para juzgar si la respuesta es única se examinan también las alternativas, las condiciones, las versiones y, cuando procede, el cálculo o el código. La solidez del fundamento varía por ID. Una palabra localizada o una página candidata sirven como pista documental y requieren leer el pasaje antes de aplicar una corrección. Para revisión editorial, empezar por las discrepancias que cambian la nota.

| Origen | Revisadas | Validadas | Parciales | Ambiguas | Incorrectas | Posible obsolescencia | Sin respaldo |
|---|---:|---:|---:|---:|---:|---:|---:|
| Oficial | 1.049 | 771 | 197 | 39 | 14 | 13 | 15 |
| Academia | 4.106 | 2.786 | 770 | 348 | 144 | 29 | 29 |
| Generada | 10.923 | 9.002 | 1.266 | 244 | 279 | 123 | 9 |
| **Total** | 16.078 | 12.559 | 2.233 | 631 | 437 | 165 | 53 |

| ID | Dictamen | Motivo | Evidencia registrada |
|---|---|---|---|
| AT407-P1-19 | Ambigua | Clave D. Son ciertos tanto el mínimo de 20 bytes como el orden de puertos origen, destino y número de secuencia. | T4.07 Modelo TCP y OSI - Test.pdf (plantilla p. 13) |
| AT408-P1-55 | Ambigua | Clave C. HTTP/2 y HTTP/3 especifican server push. El soporte concreto de navegadores no hace única la respuesta. | T4.08 Internet - Test.pdf (plantilla p. 11) |
| AT410-P1-38 | Incorrecta | Clave A. Almacenamiento y envío es la traducción de store-and-forward, una técnica convencional de conmutación. | T4.10 Redes Locales - Test.pdf (plantilla p. 10); T4.10 Redes Locales - Temario.pdf p. 32 (pasaje localizado: conmutación) |
| AS08B-P1-37 | Parcialmente respaldada | C coincide con el diagrama original visto en p. 8: el subárbol 3 produce 1,4,7,6,3; el 10 produce 13,14,10 y finalmente aparece 8. El registro textual de la app omite el árbol necesario. | T2.03 Estructuras de Datos/T2.03 Estructuras de Datos - Temario.pdf p. 18. /Volumes/SSD/Google Drive/TEMARIO_OPOSICION/RECURSOS/SIMULACROS/Simulacro 08 (bis).pdf, pregunta p. 8, solución impresa p. 17 (C), app C. |
| AS09-P1-48 | Parcialmente respaldada | Clave D confirmada en el impreso: Icono::obtenerID() lleva {leaf}, lo que impide que se redefina. El banco omite el diagrama y no permite escoger D a partir del texto. | Simulacro 09.pdf, diagrama de la pregunta 48 p. 9, plantilla p. 18. En T3.05.json solo constan el enunciado y las opciones. |
| AS10B-P1-63 | Parcialmente respaldada | Clave C confirmada por acciones, decisión, barras de bifurcación y reunión y nodos inicial y final del diagrama de actividad. La app omite la imagen necesaria para reconocerlo. | Simulacro 10 (bis).pdf, figura p. 11 y plantilla p. 16. El registro T3.05.json no incorpora la figura. |
| AS11-P1-88 | Ambigua | Clave C. La letra g invalida la clave y dos secuencias de compresión en la primera alternativa también invalidan esa dirección. | Simulacro 11.pdf (plantilla p. 17) |

Las etiquetas se refieren a los juicios registrados en esta versión. El recuento incluye las tres variantes de una familia cuando las tres resultan afectadas. Para medir cuántos conceptos necesitan una corrección distinta hay que agruparlos por premisa y comprobar cada variante. [Cobertura por tema y procedencia](banco/cobertura-por-tema.csv) · [Registro editorial por ID](anexos/incidencias-por-id.csv).

**Respaldo por pregunta.** Las 10.090 coincidencias literales proceden de citas de autoría de las generadas. Para incorporar también la evidencia localizada durante esta revisión se buscaron los nombres de los 51 PDF de teoría y una página en rango dentro de cada dictamen. 15.523 registros citan así al menos una página. De ellos, **12.288 (76,43 % de todo el banco)** combinan esa referencia con un dictamen «Validada». Son 770 oficiales, 2.522 de academia y 8.996 generadas. El indicador permite filtrar los juicios favorables con una referencia interna comprobable. Excluye referencias abreviadas que el programa no pudo identificar, así como pruebas basadas exclusivamente en cálculos, cuadernos o fuentes externas. Una página citada puede acreditar solo parte del razonamiento. [Desglose de los indicadores por ID](banco/respaldo-por-id.csv) · [Método de recuento](metodo/medir_respaldo.py).

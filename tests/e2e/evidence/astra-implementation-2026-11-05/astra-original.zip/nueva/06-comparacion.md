# 06 · Qué distingue el banco del examen y dónde revisar cobertura

**El principal desequilibrio observado es el tipo de tarea que se practica.** En los originales de autoría, 84 de 10.923 generadas (0,77 %) llevan técnica «código o cálculo», frente a 211 de 1.049 oficiales del banco (20,11 %). Los supuestos explican parte de la diferencia: separando las 680 oficiales temáticas quedan 39 con esa técnica (5,74 %), todavía por encima de las generadas. El campo «tipo de enunciado» es otro eje: existen 585 generadas de tipo K y 219 oficiales de tipo K. Mantener separados los dos criterios evita confundir presencia de código con la operación que se usa para resolver las alternativas. [Desglose por tema, origen y técnica](banco/temas-origen-patrones.csv).

| Técnica editorial atribuida al construir el banco | Oficial (1.049) | Generada (10.923) |
|---|---:|---:|
| Conceptos de la misma familia | 267 | 4.428 |
| Cambio de cifra o plazo | 119 | 3.990 |
| Deformación de una formulación literal | 258 | 2.292 |
| Código o cálculo | 211 | 84 |
| Intruso de otra familia | 128 | 63 |
| Opciones inventadas | 66 | 66 |

Son anotaciones de autoría que se pueden contrastar en el cuestionario. No constituyen motivos atribuidos al tribunal. En academia 3.848 filas carecen de técnica declarada, por lo que comparar únicamente los 258 casos etiquetados con los otros dos grupos sesgaría el resultado. La mediana y la forma lingüística por tema están en el anexo. Las medidas independientes del corpus de examen y sus exclusiones se documentan en el informe 04.

**Una pista formal permite acertar sin recuperar el concepto.** Elegir la alternativa más larga por número de palabras, repartiendo crédito por igual entre empates, arroja 51,03 % en generadas, 29,15 % en oficiales y 27,06 % en academia. Se incluyeron todos los IDs una vez y el 25 % es el valor esperado de elegir al azar entre cuatro alternativas. La regla funciona sobre estas preguntas; no estima lo que hará un candidato ni predice la letra correcta. El generador debe revisar la longitud de distractores y clave *dentro de la misma pregunta*. [Cálculo por tema y origen](anexos/pista-longitud.csv).

### Matriz de correspondencia

La [matriz tema → concepto de índice → patrón → IDs → brecha](banco/matriz-conceptos.csv) incluye 1.241 identificadores distintos de apartado candidato y sus combinaciones de patrones. El índice fuente contiene 1.242 entradas. En T1.02 aparece dos veces el ID ci-716bc3f3d307f25dda51, «Nº total Diputados». El valor 350, interpretado como página, corresponde al número de diputados. Se conserva la extracción original para poder reproducir el error. Conserva IDs por origen y las apariciones oficiales cuyos enunciados alcanzan similitud de al menos 0,85 con el texto de examen extraído. Se localizan conceptos por páginas candidatas, a partir de citas o de búsqueda léxica; varios epígrafes comparten página. La etiqueta «sin generadas asignadas» es **una prioridad para lectura editorial**, ya que una pregunta redactada de otra forma podría quedar fuera. El [índice de cobertura que solo usa páginas con citas](banco/apartados.csv) permite excluir asociaciones léxicas del análisis.

- **Numeración y árboles.** La conversión de bases apareció en P2024A-P1-R-02 y el recorrido de árboles en L2025X-P1-26. La matriz identifica sus enunciados oficiales y la escasez de generadas clasificadas como resolución sobre los apartados candidatos. El lote de razonamiento comprueba claves por cálculo o trazado. Un alumno que reconoce la definición de árbol puede aún equivocarse en el orden de visita. [Lote resuelto](anexos/lote-razonamiento.csv).
- **T4.01 Administración de SO.** Ninguno de sus 42 epígrafes obtiene una asignación por la regla de citas físicas del índice. Las preguntas del tema sí existen. Es necesario reconciliar los PDF y sus versiones antes de interpretar el vacío como carencia conceptual. En T1.10 hay 26 de 75 epígrafes sin ese vínculo, en T1.07 son 24 de 41 y en T3.09 son 23 de 28. El conteo bruto es 279 de 1.242 entradas sin vínculo por cita física. Doce filas de T1.02 (11 IDs distintos) proceden de la tabla de mayorías de la página física 11 y carecen de valor como epígrafes. Al excluirlas quedan 1.230 entradas distintas con paginación en rango y 267 sin vínculo. La validez temática de otros candidatos requiere examen editorial. [Filas descartadas y motivo](anexos/filas-de-indice-descartadas.csv). [Detalle de las páginas](banco/apartados.csv).
- **Familias y redundancia.** GEN-T2.05-22 y GEN-T4.02-12 comparten enunciado, clave y opciones, permutadas, sobre la granularidad de Oracle. Las funciones de estudio podrán diferenciar exposición repetida de preguntas realmente nuevas si conservan ambos IDs y relacionan el concepto. Otras 59 parejas son candidatas por similitud, sin prueba de equivalencia semántica. La comparación exige igual clave de texto y contexto, familias distintas y similitud Jaccard de al menos 0,60 en trigramas de palabras del enunciado. Un cupo de práctica por familia protege mejor la diversidad de una sesión que contar tres variantes como tres conceptos. [Pares para cotejo](banco/proximidad.csv) · [Duplicado con opciones permutadas](banco/duplicados-exactos.csv).

Para decidir nuevas preguntas se necesita identificar, de cada concepto con apariciones oficiales, **qué sabe hacer quien responde bien**: recordar, comparar, calcular, ejecutar mentalmente o aplicar la regla de un supuesto. Un dato nuevo por cada tema no cubriría las carencias de razonamiento que muestran esos ejemplos.

### Cruce con los patrones leídos directamente en los exámenes

Un segundo anexo parte de las 40 lecturas individuales del equipo sobre cuadernos oficiales (39 ejemplos utilizables y una anulación). Por cada ejemplo conserva el concepto, el patrón revisado, la operación cognitiva, la pregunta exacta y el ID operativo, cuando se consigue enlazarlo. La búsqueda por término o expresión regular documentada se limita al enunciado y la clave de las preguntas del mismo tema; incluye tanto academia como generadas. Estas últimas son candidatas conceptuales, incluso cuando el vocabulario coincide: «RAID» puede servir para reconocer una sigla o para calcular capacidad. Leer las alternativas es indispensable antes de declarar cubierta esa capacidad. [Matriz de patrones revisados y preguntas actuales](banco/matriz-patrones-revisados.csv).

<!-- RESULTADOS DEL CENSO -->
## Temas con más preguntas que requieren adjudicación

Se ordenan por cantidad de dictámenes incorrectos, ambiguos, potencialmente obsoletos o sin respaldo. Esta tabla permite distribuir el trabajo de los editores. La proporción usa como denominador las preguntas revisadas de cada tema. Las que solo requieren completar o precisar la evidencia figuran aparte en el CSV. La cobertura de conceptos del temario se mide en la matriz de epígrafes anterior.

| Tema | Incidencias de los cuatro estados | IDs revisados | Proporción |
|---|---:|---:|---:|
| T3.08 | 188 | 1.829 | 10,28 % |
| T3.06 | 133 | 1.603 | 8,30 % |
| T2.04 | 58 | 621 | 9,34 % |
| T4.02 | 52 | 709 | 7,33 % |
| T3.07 | 52 | 715 | 7,27 % |
| T2.03 | 52 | 488 | 10,66 % |
| T3.02 | 44 | 393 | 11,20 % |

[Cobertura por tema y procedencia](banco/cobertura-por-tema.csv) · [Registro editorial por ID](anexos/incidencias-por-id.csv).

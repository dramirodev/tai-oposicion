# 02 · Qué preguntas contiene la aplicación

El censo registra **16.078 IDs únicos**, conservando una sola fila cuando distintos modos de estudio o modelos de examen utilizan la misma pregunta. La identidad del banco local se contrastó con el banco remoto de la versión 12. [Inventario completo, una pregunta por línea](banco/inventario.jsonl) · [Verificación Firestore](evidencia-tecnica/firestore.json).

| Fuente declarada | 36 temas | 32 supuestos | Total |
|---|---:|---:|---:|
| Exámenes oficiales | 680 | 369 | 1.049 |
| Academia | 4.058 | 48 | 4.106 |
| Generadas | 10.923 | 0 | 10.923 |
| **Total** | **15.661** | **417** | **16.078** |

**Dónde está la pregunta.** Las filas temáticas se leen de los archivos `public/data/T*.json`; los contextos y sus preguntas están en `public/data/supuestos.json`. El índice temático `meta.json` incluye cinco alias adicionales para preservar identificadores antiguos. La muestra pública replica 360 IDs sin cambios de enunciado, opciones ni clave. Los resultados, los fallos y los repasos adaptativos reutilizan IDs del banco. La elegibilidad final depende de las opciones de sesión, el contexto, la cuarentena y el progreso del estudiante. El anexo describe modalidades posibles, sin atribuir sesiones o exposiciones personales.

**Dónde se preparó.** El cruce por identificador recuperó el origen de las 16.078 filas en los archivos de autoría de Drive: `banco_literal.json`, `banco_academia.json` y los bancos por tema de `generadas/`. Se preserva la colección de apariciones para reconstruir las variantes oficiales. El origen operativo A/O/G y las rutas identifican la procedencia disponible. El banco carece de una clasificación histórica completa por editor humano, modelo de IA o acto de importación. Dos colas separadas conservan 16 registros oficiales y uno de academia fuera del banco activo. [Colas documentales, con motivos y datos originales](banco/cola-no-publicada.jsonl).

**Cómo leer los datos individuales.** Cada línea JSON incluye archivo técnico y de autoría, tema, enunciado, opciones, letra y texto correctos, familia, nivel estimado, nota editorial, extracto mostrado, ficha de explicación de código, supuestos, convocatoria, páginas de referencia y dictamen. Cuando existe un pasaje localizado, se enumeran los apartados cuyo inicio impreso resulta más cercano en el mismo documento. Múltiples apartados en una misma página pueden producir varios candidatos. La ruta relativa de un PDF en un anexo empieza en `01_Temario`; el registro de PDF proporciona ruta absoluta, versión por SHA-256, páginas y clase de documento. [PDF y huellas](banco/pdf-cotejados.csv) · [Desglose por tema y origen](banco/temas-origen-patrones.csv).

**Qué se comprobó en todas las filas.** Unicidad del ID, integridad del enunciado, cuatro alternativas no vacías y distintas, validez del índice de la clave, enlace con los originales y consistencia de la muestra. Los comandos, identificadores y opciones se compararon conservando mayúsculas. Las comprobaciones estructurales no detectaron un ID duplicado ni una clave fuera de rango. Hay 220 registros con alguna diferencia de enunciado, opciones o clave respecto a la fuente de autoría. La reconstrucción técnica compara además otros campos. La pregunta publicada prevalece para describir qué verá el estudiante. [Reconstrucción](evidencia-tecnica/cambios-de-reconstruccion.csv) · [Auditor nativo ejecutado sobre las fuentes](evidencia-tecnica/auditor-nativo.json).

**Qué significan las etiquetas.** Las 10.923 generadas se agrupan en 3.641 familias, cada una con tres versiones. Permiten medir exposición repetida al mismo concepto. La etiqueta de dificultad es editorial. En academia faltan niveles para 3.848 de 4.106, y 498 tienen marca de tema dudoso. En generadas, 6.909 figuran en nivel 3; en oficiales, 137 de 1.049. Estos números describen un etiquetado y no permiten comparar dificultad empírica. En 5.004 IDs la fuente Drive declara revisión parcial y el banco publicado tiene `v=0`. Comparar ambas versiones antes de interpretar ese campo como prueba de revisión. [Conteos y señales de discrepancia](banco/resumen.json).

<!-- RESULTADOS DEL CENSO -->
## Cobertura de la revisión en el banco publicado

El ID que recibe el estudiante es la unidad de recuento. El registro distingue el estado de cada pregunta de sus apariciones en modelos A/B, sus variantes de familia y sus formas de uso.

| Origen | Revisadas | Validadas | Parciales | Ambiguas | Incorrectas | Posible obsolescencia | Sin respaldo |
|---|---:|---:|---:|---:|---:|---:|---:|
| Oficial | 1.049 | 771 | 197 | 39 | 14 | 13 | 15 |
| Academia | 4.106 | 2.786 | 770 | 348 | 144 | 29 | 29 |
| Generada | 10.923 | 9.002 | 1.266 | 244 | 279 | 123 | 9 |
| **Total** | 16.078 | 12.559 | 2.233 | 631 | 437 | 165 | 53 |

[Cobertura por tema y procedencia](banco/cobertura-por-tema.csv) · [Firmas sobre el contenido revisado](banco/firmas-de-contenido.csv).

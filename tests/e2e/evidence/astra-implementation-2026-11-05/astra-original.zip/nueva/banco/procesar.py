"""Rehacer inventario desde las fuentes. python3 procesar.py [--salida ...]"""
import argparse,collections,csv,functools,hashlib,json,math,re,subprocess,unicodedata
from pathlib import Path
P=argparse.ArgumentParser();P.add_argument('--repo',type=Path,default=Path('/Volumes/SSD/develop/tai-oposicion'));P.add_argument('--raiz',type=Path,default=Path('/Volumes/SSD/Google Drive/TEMARIO_OPOSICION'));P.add_argument('--salida',type=Path,default=Path(__file__).parent);a=P.parse_args()
R,D,O=a.repo,a.raiz,a.salida;O.mkdir(exist_ok=True,parents=True);S=D/'01_Temario';B=D/'BANCO_PREGUNTAS'
read=lambda p:json.loads(p.read_text())
def csvfile(name,rows):
 with (O/name).open('w') as f:
  w=csv.DictWriter(f,rows[0].keys());w.writeheader();w.writerows(rows)
def norm(x):return ' '.join(unicodedata.normalize('NFC',x).split())
def compact(x):return ''.join(norm(x).split()).replace('\xad','')
stop=set('por del los las para una uno con que qué cuál cuáles como cómo este esta estos estas son figura siguiente siguientes señale indique opción opciones respuesta respuestas correcto correcta según sobre relación respecto cuando hace hace hace sistema puede debe entre todos tiene todo será siendo mismo están'.split())
def terms(x):return set(re.findall(r'\b[\w#-]{3,}\b',x.lower()))-stop
def ts(p):return json.JSONDecoder().raw_decode(p.read_text().split(' = ',1)[1])[0]
def filehash(p):return hashlib.sha256(p.read_bytes()).hexdigest()
pages={};files=[];indexes={};sec={};allsec=[]
for folder in sorted(p for p in S.iterdir() if re.match(r'T\d\.\d\d ',p.name)):
 t=folder.name[:5];pages[t]=[];sec[t]=[]
 outline=R/'src/core/domain/academy-curriculum.generated'/f'{t}.generated.ts';docs=ts(outline) if outline.exists() else {}
 allowed={}
 for p in sorted(folder.glob('*.pdf')):
  primary='temario' in p.stem.casefold() or p.name=='B3T5_POO 1.pdf'; supplemental=t=='T3.06' and ' - Resumen - ' in p.name
  if not(primary or supplemental):continue
  fp=str(p.relative_to(S));allowed[fp]=filehash(p);ty='principal' if primary else 'resumen'
  ext=subprocess.check_output(['pdftotext','-layout',str(p),'-']).decode();split=ext.split('\f');split.pop() if split[-1]=='' else None
  for pg,text in enumerate(split,1):
   if text.strip():pages[t].append(dict(pdf=fp,pagina=pg,clase=ty,txt=text,cmp=compact(text),terms=terms(text)))
  files.append(dict(tema=t,ruta=str(p),clase=ty,sha256=allowed[fp],paginas=len(split),con_texto=sum(bool(x.strip()) for x in split)))
 for s in docs.get('sections',[]):
  if s['materialPath'] in allowed and s.get('sourceHash')==allowed[s['materialPath']] and s.get('printedPage'):
   sec[t].append((s['materialPath'],s['printedPage'],s['title'],s['id']));allsec.append((t,*sec[t][-1]))
 ind=collections.defaultdict(list)
 for j,page in enumerate(pages[t]):
  for word in page['terms']:ind[word].append(j)
 indexes[t]=ind
csvfile('pdf-cotejados.csv',files)
def closest(t,q):
 words=terms(q['q']);ans=terms(q['a'][q['c']]);scores=collections.Counter();index=indexes.get(t,{})
 for w in words|ans:
  posts=index.get(w,[]);weight=math.log((len(pages.get(t,[]))+1)/(len(posts)+1))**2*(1.5 if w in words else 1)
  for j in posts:scores[j]+=weight
 return scores.most_common(2)
@functools.lru_cache(None)
def locate(t,s,preferred):
 needle=compact(s)
 if len(needle)<25:return []
 return sorted((j for j,p in enumerate(pages.get(t,[])) if needle in p['cmp']),key=lambda j:(pages[t][j]['clase']!='principal',pages[t][j]['pagina']!=preferred,'alternativa' in pages[t][j]['pdf'],j))
def anchor(t,j):
 p=pages[t][j];applicable=[(pg,name,id) for path,pg,name,id in sec[t] if path==p['pdf'] and pg<=p['pagina']]
 last=max((v[0] for v in applicable),default=None)
 return dict(pdf=p['pdf'],pagina=p['pagina'],clase=p['clase'],apartados_candidatos=[id for pg,title,id in applicable if pg==last])
raw={};unpublished=[];provenance={}
for f in [B/'banco_literal.json',B/'banco_academia.json',*sorted((B/'generadas').glob('banco_generado_T*.json'))]:
 for q in read(f)['preguntas']:
  assert q['id'] not in raw;qid=q['id'];raw[qid]=q;provenance[qid]=str(f)
repo=R/'public/data';index=read(repo/'index.json');meta=read(repo/'meta.json');aliases=collections.defaultdict(list)
for alias,value in meta.items():
 if len(value)>5:aliases[value[-1]].append(alias)
records=[(q,str(f),None) for f in sorted(repo.glob('T*.json')) for q in read(f)]
scenario=read(repo/'supuestos.json');records += [(q,str(repo/'supuestos.json'),k) for k,s in scenario.items() for q in s['q']]
sample={q['i']:q for f in (R/'public/sample').glob('T*.json') for q in read(f)}
e={x['i']:x for x in read(R/'public/explanations/index.json')}
manual=read(Path(__file__).with_name('dictamenes.json')) if Path(__file__).with_name('dictamenes.json').exists() else {}
seen=set();gr=collections.defaultdict(list); near=collections.defaultdict(list);families=collections.defaultdict(list);bysec=collections.defaultdict(list);data=[];technical=collections.Counter()
for q,loc,scenario_id in records:
 i=q['i'];t=q['t'];o=q['o'];r=raw.get(i,{});opts=q['a'];c=q['c'];assert i not in seen;seen.add(i)
 alerts=[]
 if len(opts)!=4 or len(set(map(norm,opts)))!=4 or not q['q'].strip() or any(not x.strip() for x in opts) or type(c)!=int or not 0<=c<len(opts): alerts.append('estructura')
 if i in sample and any(sample[i].get(k)!=q.get(k) for k in ['q','a','c']):alerts.append('muestra-divergente')
 if r and (q['q']!=r['enunciado'] or opts!=[r['opciones'][x] for x in 'abcd'] or 'abcd'[c]!=r['correcta']):alerts.append('texto-opciones-clave-distintos-de-autoria')
 if q.get('p'):alerts.append('provisional-en-banco')
 if q.get('np'):alerts.append('no-puntuable-en-banco')
 if q.get('w'):alerts.append('caducable-en-banco')
 if q.get('z'):alerts.append('tema-dudoso-en-banco')
 if r.get('revision',{}).get('estado')=='verificada_parcial' and q.get('v')==0: alerts.append('revision-parcial-en-autoria-v0-en-banco')
 findings=[];jlist=[]
 for ct in r.get('cita_temario',[]):
  candidates=locate(t,ct.get('texto',''),ct.get('pagina'))
  if candidates:jlist.append(candidates[0])
  findings.append(dict(original=ct,coincidencias=len(candidates),localizacion=anchor(t,candidates[0]) if candidates else None))
 best=None
 if not jlist:
  scores=closest(t,q)
  if scores:best=anchor(t,scores[0][0]);best['peso_lexico']=round(scores[0][1],3)
 for sid in set(s for j in jlist for s in anchor(t,j)['apartados_candidatos']):bysec[sid].append(i)
 diag=[]
 for option in opts:
  opt=compact(option.strip().strip('.'))
  diag.append(any(opt in pages[t][j]['cmp'] for j in jlist) if len(opt)>=12 and jlist else None)
 row=dict(id=i,tema=t,procedencia=o,archivo=loc,autor=str(provenance.get(i,'')),modalidad='supuesto práctico' if scenario_id else 'banco temático compartido por test, simulacro, repasos y entrenadores según filtros',supuesto=scenario_id,aliases=aliases.get(i,[]),apariciones=r.get('aparece_en',[]),muestra_publica=i in sample,fuente_de_pregunta=r.get('fuente'),convocatoria=r.get('convocatoria'),pregunta=q['q'],opciones=opts,clave='ABCD'[c],respuesta=opts[c],nota=q.get('n'),extracto_visible=q.get('u'),ficha_codigo=e.get(i),nivel_estimado=q.get('d'),familia=q.get('f'),tipo_autoria=r.get('tipo'),tecnica_autoria=r.get('tecnica'),naturaleza_autoria=r.get('naturaleza'),citas=findings,pagina_busqueda=best,opciones_literales_en_paginas_de_cita=diag,alertas=alerts,juicio=manual.get(i),estado=(manual[i]['estado'] if i in manual else 'Parcialmente respaldada' if jlist else 'Pendiente de revisión'))
 data.append(row);gr[(norm(q['q']),tuple(sorted(norm(z) for z in opts)),scenario_id)].append((i,opts[c]));near[(norm(opts[c]),scenario_id)].append((i,q.get('f'),q['q']))
 if q.get('f'):families[q['f']].append(i)
for f in [B/'banco_revisar.json',B/'banco_academia_revisar.json']:
 for q in read(f)['preguntas']:unpublished.append({'fuente':str(f),'es_activa':q['id'] in seen,'fila':q})
for name,rows in [('inventario.jsonl',data),('cola-no-publicada.jsonl',unpublished)]:
 with (O/name).open('w')as f:
  for item in rows:f.write(json.dumps(item,ensure_ascii=False)+'\n')
csvfile('apartados.csv',[dict(tema=t,documento=p,pagina_impresa=pg,concepto=title,apartado=id,candidatos=len(bysec[id]),ids=' | '.join(bysec[id])) for t,p,pg,title,id in allsec])
dup=[dict(ids=' | '.join(v[0] for v in g),enunciado=k[0],claves=' | '.join({v[1] for v in g})) for k,g in gr.items() if len(g)>1];csvfile('duplicados-exactos.csv',dup)
pairs=[]
for (answer,s),qs in near.items():
 old=[]
 for i,f,txt in qs:
  w=norm(txt).split();grams=set(zip(w,w[1:],w[2:])); 
  if len(grams)<5:continue
  for other,of,og in old:
   if f and f==of:continue
   sim=len(og&grams)/len(og|grams)
   if sim>=.60:pairs.append(dict(id_a=other,id_b=i,similitud=round(sim,3),respuesta=answer))
  old.append((i,f,grams))
csvfile('proximidad.csv',pairs)
summary=dict(n=len(data),tematicas=index['n'],supuestos=index['nsup'],contextos=len(scenario),muestra=len(sample),muestra_extra=sorted(sample.keys()-seen),aliases=sum(map(len,aliases.values())),ids_sin_autor=sorted(seen-raw.keys()),ids_autor_sin_checkout=sorted(raw.keys()-seen),familias=len(families),tamanos_familia=collections.Counter(map(len,families.values())),coinciden=sum(any(c['localizacion'] for c in x['citas']) for x in data),coinciden_principal=sum(any(c['localizacion'] and c['localizacion']['clase']=='principal' for c in x['citas']) for x in data),por_estado=collections.Counter(q['estado'] for q in data),origen=collections.Counter(x['procedencia'] for x in data),alertas=collections.Counter(a for x in data for a in x['alertas']),duplicados_grupos=len(dup),proximos=len(pairs),con_revision=len(manual),n_pdf=len(files),pags=sum(f['con_texto'] for f in files))
(O/'resumen.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2))
print(summary)

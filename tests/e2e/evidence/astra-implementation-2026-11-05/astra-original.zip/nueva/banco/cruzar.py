"""Compara cada aparición canónica con su cuaderno y plantilla independiente."""
from pathlib import Path
import json,csv,re,collections,unicodedata,difflib,statistics
O=Path(__file__).parent
def readj(name):return [json.loads(x) for x in (O/name).open()]
def write(name,rows):
 with (O/name).open('w') as f:
  w=csv.DictWriter(f,rows[0].keys());w.writeheader();w.writerows(rows)
def norm(s):return ''.join(c for c in unicodedata.normalize('NFKC',s or '').lower() if c.isalnum())
raw=readj('inventario.jsonl');by_off={q['id']:q for q in csv.DictReader((O.parent/'oficial/preguntas.csv').open()) if q['id'].startswith('TAI')}
def official_id(id):
 head,suffix=id.split('-',1)
 h={'TAI2024B':'2024-L-B','TAIL2022':'2022-L-U','L2018S':'2018-L-II'}.get(head)
 if not h:
  access,year,model=re.fullmatch(r'([LP])(\d{4})([ABX]?)',head).groups();h=f'{year}-{access}-{model or "U"}'
 return 'TAI-'+h+'-'+suffix.replace('-R-','R-')
rows=[]; qmap={}; 
for q in raw:
 if q['procedencia']!='O':continue
 proof=[]
 for iid in q['apariciones']:
  target=official_id(iid);r=by_off.get(target,{})
  options=[r.get(k,'') for k in 'abcd'];letter=r.get('definitiva','');oi='ABCD'.find(letter) if letter in ['A','B','C','D'] else -1
  same=[norm(o) for o in q['opciones']]==[norm(o) for o in options]
  stem_sim=difflib.SequenceMatcher(None,norm(q['pregunta']),norm(r.get('enunciado','')),autojunk=False).ratio()
  if not r:judg='fuera del índice'
  elif letter=='ANULADA':judg='anulada en definitiva'
  elif oi<0:judg='sin letra definitiva'
  elif norm(q['respuesta'])==norm(options[oi]):judg='coincide el texto de la alternativa correcta'
  elif same:judg='contradicción con opciones iguales'
  else:judg='requiere cotejo visual de textos'
  rows.append(dict(banco=q['id'],aparicion=iid,oficial=target,pdf_cuaderno=r.get('cuaderno'),pagina=r.get('pagina'),similitud_enunciado=round(stem_sim,3),cuatro_opciones_mismo_orden=same,clave_banco=q['clave'],clave_definitiva=letter,dictamen=judg,np='no-puntuable-en-banco' in q['alertas']))
  if stem_sim>=.85 and r:proof.append(target)
 qmap[q['id']]=proof
write('contraste-plantillas.csv',rows)
# Señales independientes de forma y técnicas declaradas. Cruce conceptual por página verificable o candidata.
def patterns(q):
 out=[];stem=q['pregunta'];k=q['tecnica_autoria']
 if re.search(r'\b(INCORRECT[AO]|FALS[AO]|EXCEPTO|SALVO)\b',stem,re.I):out.append('inversa explícita')
 if k in ['M','K','F','H','X','V']:out.append(dict(M='cifra o plazo',K='código o cálculo',F='deformación literal',H='conceptos hermanos',X='intruso entre familias',V='opciones inventadas')[k])
 return out
by_topic=collections.defaultdict(list);bysect=collections.defaultdict(list);byid={q['id']:q for q in raw}
for q in raw:
 by_topic[(q['tema'],q['procedencia'])].append(q);links={sid for c in q['citas'] if c['localizacion'] for sid in c['localizacion']['apartados_candidatos']}
 if not links and q['pagina_busqueda']:links.update(q['pagina_busqueda']['apartados_candidatos'])
 for section in links:bysect[section].append(q)
by=[]
for (t,o),qs in sorted(by_topic.items()):
 ds=collections.Counter(p for q in qs for p in patterns(q));n=len(qs)
 by.append(dict(tema=t,origen=o,n=n,nivel_sin_indicar=sum(not q['nivel_estimado'] for q in qs),con_cita_localizada=sum(any(v['localizacion'] for v in q['citas']) for q in qs),con_nota=sum(bool(q['nota']) for q in qs),longitud_mediana=statistics.median(len(q['pregunta'].split()) for q in qs),**{k:ds[k] for k in ['inversa explícita','cifra o plazo','código o cálculo','deformación literal','conceptos hermanos','intruso entre familias','opciones inventadas']}))
write('temas-origen-patrones.csv',by)
mat=[]
for row in csv.DictReader((O/'apartados.csv').open()):
 candidate=bysect[row['apartado']]
 by_prov={o:[q for q in candidate if q['procedencia']==o] for o in 'OAG'}
 pats={}
 for o,li in by_prov.items():pats[o]=collections.defaultdict(list);[(pats[o][p].append(q['id'])) for q in li for p in patterns(q)]
 for p in sorted(set(pats['O'])|set(pats['G'])|set(pats['A'])) or ['sin coincidencia']:
  official_examples=[v for i in pats['O'][p] for v in qmap.get(i,[])]
  mat.append(dict(tema=row['tema'],concepto_indice=row['concepto'],ruta=row['documento'],pagina_impresa=row['pagina_impresa'],apartado=row['apartado'],patron=p,apariciones_oficiales_texto_similar=' | '.join(official_examples),ids_banco_oficial=' | '.join(pats['O'][p]),ids_banco_academia=' | '.join(pats['A'][p]),ids_banco_generadas=' | '.join(pats['G'][p]),lectura='patrón oficial candidato sin generadas asignadas' if official_examples and not pats['G'][p] else 'sin anclaje oficial por este método' if not official_examples else 'coincidencia candidata'))
write('matriz-conceptos.csv',mat)
print('plantillas',collections.Counter(r['dictamen'] for r in rows),'conceptos/patrones',len(mat))
# Un segundo cruce usa los conceptos y familias de patrón revisados en la lectura directa.
samples=list(csv.DictReader((O.parent/'oficial/muestra-revisada.csv').open()))
keywords=['tribunal constitucional','ssd','ruby on rails','multicast','required','final','subred','raid','circunscripci','usb','rest','plastica|plástica|\\bpof\\b','hashset|treeset|conjunto|duplicad','microservicio','thin provisioning|aprovisionamiento fino','wifi|wi-fi|802\\.11','\\brey\\b','foránea|foranea|foreign key','días hábiles|días naturales','\\bosi\\b','insert into|\\binsert\\b','wsdl','https','amenaza persistente|\\bapt\\b','diputación permanente','\\bipp\\b','wsdl','conmutación de (?:circuitos|paquetes)','group by','atributo.{0,35}xml|xml.{0,35}atributo','subred','test-netconnection|netcat|telnet','cortes generales','json','coerción|igualdad|==',r'\bsip\b','contenedor|flexbox','sniffing|x-content-type-options','hostname','new-adreplicationsite']
assert len(keywords)==len(samples)
curated=[]
for v,regex in zip(samples,keywords):
 assert v['id'] in by_off
 topic=v['tema'];matches=[q for q in raw if q['tema']==topic and re.search(regex,q['pregunta']+' '+q['respuesta'],re.I)]
 def listed(o):return ' | '.join(q['id'] for q in matches if q['procedencia']==o)
 official=by_off[v['id']];canonical=[q['id'] for q in raw if q['procedencia']=='O' and v['id'] in qmap.get(q['id'],[])]
 if v['patron']=='ANU':gap='excluida del modelado por anulación'
 elif not listed('G'):gap='sin generadas detectadas por el filtro conceptual'
 else:gap='validar que las candidatas exijan la operación observada'
 curated.append(dict(tema=topic,concepto=v['concepto'],patron_revisado=v['patron'],demanda=v['demanda'],examen=v['id'],pagina=v['pagina'],id_canonico=' | '.join(canonical),busqueda=regex,ids_generadas=listed('G'),ids_academia=listed('A'),brecha=gap))
write('matriz-patrones-revisados.csv',curated)
